import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;


/**
 * Clase de pruebas unitarias para SilkRoad.
 * Laura Castillo y Mariana Malagón
 * 16/09/2025
 */
public class SilkRoadTestLCMM {

    private SilkRoad road;

    /**
     * Configuración inicial antes de cada test.
     * Crea una nueva instancia de SilkRoad para cada prueba.
     */
    @Before
    public void setUp() {
        road = new SilkRoad(10);
    }

    /**
     * Prueba que verifica el cálculo correcto de la ganancia neta.
     * Robot se mueve 5 metros para robar una tienda con 100 tenges.
     * Ganancia neta esperada: 100 - 5 = 95
     */
    @Test
    public void accordingLCMMShouldCalculateNetProfitCorrectly() {
        road.placeStore(0, 100);
        road.placeRobot(5);
        road.moveRobot(5, -5);
        assertTrue("Ganancia neta debería ser 95 (100 - 5)", road.profit() == 95);
    }

    /**
     * Prueba que verifica el manejo correcto de ganancias negativas.
     * Robot se mueve 10 metros para robar una tienda con solo 3 tenges.
     * Ganancia neta: 3 - 10 = -7 → no debe añadirse al profit (0 esperado)
     */
    @Test
    public void accordingLCMMShouldHandleNegativeProfit() {
        road.placeStore(0, 3);
        road.placeRobot(10);
        road.moveRobot(10, -10);
        assertTrue("Ganancia debería ser 0 (3 - 10 = -7)", road.profit() == 0);
    }

    /**
     * Prueba que verifica el tracking de ganancias por movimiento.
     * Robot realiza dos movimientos y se verifica que las ganancias
     * se registren correctamente para cada movimiento.
     */
    @Test
    public void accordingLCMMShouldTrackMovementEarnings() {
        road.placeStore(0, 100);
        road.placeStore(20, 50);
        road.placeRobot(5);
        road.moveRobot(5, -5); 
        road.moveRobot(0, 20);

        int[][] earnings = road.profitPerMove();
        
        assertTrue("Debería tener 1 robot", earnings.length == 1);
        assertTrue("Debería tener 2 movimientos", earnings[0].length == 2);
        assertTrue("Primer movimiento debería ganar 95", earnings[0][0] == 95);
        assertTrue("Segundo movimiento debería ganar 30", earnings[0][1] == 30);
    }


    /**
     * Prueba que verifica la extensión de creación desde arrays.
     * Se crea una ruta completa desde arrays de entrada.
     */
    @Test
    public void accordingLCMMShouldCreateFromArrays() {
        int[][] storesInfo = {{0, 100}, {5, 50}, {10, 200}};
        int[][] robotsInfo = {{2}, {8}};
        road.createExtension(storesInfo, robotsInfo);

        int[][] stores = road.stores();
        int[][] robots = road.robots();
        
        assertTrue("Debería tener 3 tiendas", stores.length == 3);
        assertTrue("Debería tener 2 robots", robots.length == 2);
        assertTrue("Primera tienda en ubicación 0", stores[0][0] == 0);
        assertTrue("Primera tienda con 100 tenges", stores[0][1] == 100);
    }

    /**
     * Prueba que verifica la extensión de movimiento automático.
     * Los robots eligen automáticamente la tienda con mejor ganancia.
     */
    @Test
    public void accordingLCMMShouldMoveRobotsToMaximizeProfit() {
        road.placeStore(0, 30);  
        road.placeStore(15, 100);
        road.placeRobot(5);
        road.moveRobotExtension();
        int[][] robots = road.robots();
        int[][] stores = road.stores();
        assertTrue("Robot debería haberse movido", robots[0][0] != 5);
    }

    /**
     * Prueba que verifica el funcionamiento del reboot y contador de días.
     * Cada reboot incrementa el contador de días y guarda las ganancias.
     */
    @Test
    public void accordingLCMMShouldTrackDaysCorrectly() {
        road.placeStore(0, 100);
        road.placeRobot(5);
        road.moveRobot(5, -5);
        road.reboot();
        
        road.moveRobot(0, 0);
        road.reboot();
 
        int[] dailyProfits = road.getDailyProfits();
        int dayCount = road.getDayCount();
        
        assertTrue("Debería tener 2 días registrados", dailyProfits.length == 2);
        assertTrue("Día 1 debería tener ganancia 95", dailyProfits[0] == 95);
        assertTrue("Día 2 debería tener ganancia 0", dailyProfits[1] == 0);
        assertTrue("Contador de días debería ser 2", dayCount == 2);
    }

    /**
     * Prueba que verifica el comportamiento de finish().
     * Al llamar finish(), todo debe reiniciarse completamente.
     */
    @Test
    public void accordingLCMMShouldResetCompletelyOnFinish() {
        road.placeStore(0, 100);
        road.placeRobot(5);
        road.moveRobot(5, -5);
        road.reboot();
        road.finish();
 
        int[][] stores = road.stores();
        int[][] robots = road.robots();
        int[] dailyProfits = road.getDailyProfits();
        
        assertTrue("No debería tener tiendas después de finish", stores.length == 0);
        assertTrue("No debería tener robots después de finish", robots.length == 0);
        assertTrue("No debería tener días registrados después de finish", dailyProfits.length == 0);
        assertTrue("Profit debería ser 0 después de finish", road.profit() == 0);
    }

    /**
     * Prueba que verifica la usabilidad de tiendas vacías.
     * Las tiendas sin stock deben cambiar su apariencia visual.
     */
    @Test
    public void accordingLCMMShouldShowEmptyStoresDifferent() {
        road.placeStore(0, 100);
        road.placeRobot(5);
        int[][] storesBefore = road.stores();
        assertTrue("Tienda debería tener stock inicial", storesBefore[0][1] == 100);
        road.moveRobot(5, -5);
        int[][] storesAfter = road.stores();
        assertTrue("Tienda debería estar vacía después de robo", storesAfter[0][1] == 0);
    }

    /**
     * Prueba que verifica el manejo de ubicaciones inválidas.
     * Las operaciones con ubicaciones fuera de rango deben fallar.
     */
    @Test
    public void accordingLCMMShouldHandleInvalidLocations() {
        road.placeStore(100, 50);
        assertFalse("placeStore con ubicación inválida debería fallar", road.ok());
        
        road.placeRobot(150);
        assertFalse("placeRobot con ubicación inválida debería fallar", road.ok());
        
        road.moveRobot(200, 5);
        assertFalse("moveRobot con ubicación inválida debería fallar", road.ok());
    }
}