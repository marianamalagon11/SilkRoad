/**
 * Clase que representa una barra de progreso gráfica.
 * Muestra visualmente el progreso de un valor en relación a un máximo.
 * Laura Castillo y Mariana Malagón
 * 16/09/2025
 */
public class ProgressBar {
    private Rectangle background;
    private Rectangle foreground;
    private int width, height;

    /**
     * Constructor que crea una nueva barra de progreso con las dimensiones especificadas.
     * 
     * @param width  el ancho total de la barra de progreso en píxeles
     * @param height el alto de la barra de progreso en píxeles
     */
    public ProgressBar(int width, int height) {
        this.width = width;
        this.height = height;

        background = new Rectangle();
        background.changeColor("black");
        background.changeSize(height, width);
        background.moveTo(100, 550);

        foreground = new Rectangle();
        foreground.changeColor("green");
        foreground.changeSize(height, 0);
        foreground.moveTo(100, 550);
    }

    /**
     * Actualiza el estado de la barra de progreso basado en el valor actual y máximo.
     * 
     * @param value el valor actual del progreso
     * @param max  el valor máximo posible del progreso
     */
    public void update(int value, int max) {
        int filledWidth = (max > 0) ? (value * width / max) : 0;
        foreground.changeSize(height, filledWidth);
    }

    /**
     * Hace visible la barra de progreso.
     */
    public void makeVisible() {
        background.makeVisible();
        foreground.makeVisible();
    }

    /**
     * Hace invisible la barra de progreso.
     */
    public void makeInvisible() {
        background.makeInvisible();
        foreground.makeInvisible();
    }
}