import java.util.*;

/**
 * Clase que representa SilkRoad, gestiona las tiendas, los robots y sus interacciones.
 * La ruta sigue un patrón en espiral cuadrado visible y los robots pierden metros al robar.
 * Permite colocar o remover tiendas y robots, mover robots para robar tiendas, y guardar y ver las ganancias.
 * Laura Castillo y Mariana Malagón
 * 16/09/2025
 */
public class SilkRoad {
    private int length;
    private ArrayList<Store> stores;
    private ArrayList<Robot> robots;
    private int profit;
    private ProgressBar bar;
    private boolean lastOk;
    private int[][] spiralMap;
    private ArrayList<Line> spiralLines;
    private int dayCount;
    private ArrayList<Integer> dailyProfits;
    private ArrayList<int[]> storeRobbedCounts;
    private ArrayList<ArrayList<Integer>> robotMovementEarnings;

    /**
     * Constructor que crea una nueva instancia de SilkRoad.
     * 
     * @param length La longitud de la ruta
     */
    public SilkRoad(int length) {
        this.length = length;
        this.stores = new ArrayList<>();
        this.robots = new ArrayList<>();
        this.profit = 0;
        this.lastOk = true;
        this.bar = new ProgressBar(300, 20);
        this.spiralLines = new ArrayList<>();
        this.dayCount = 0;
        this.dailyProfits = new ArrayList<>();
        this.storeRobbedCounts = new ArrayList<>();
        this.robotMovementEarnings = new ArrayList<>();
        this.generateSpiralMap();
        this.drawSpiral();
    }

    /**
     * Genera el mapa de espiral para convertir ubicaciones lineales a coordenadas espirales.
     */
    private void generateSpiralMap() {
        spiralMap = new int[length * length][2];
        
        if (length <= 0) return;
        
        int center = length / 2;
        int x = center;
        int y = center;
        int direction = 0;
        int stepSize = 1;
        int stepCount = 0;
        int stepsTaken = 0;
        
        int[][] directions = {{1, 0}, {0, 1}, {-1, 0}, {0, -1}};
        
        spiralMap[0][0] = x;
        spiralMap[0][1] = y;
        
        int currentX = x * 60 + 30;
        int currentY = y * 60 + 30;

        for (int i = 1; i < length * length; i++) {
            x += directions[direction][0];
            y += directions[direction][1];
            stepsTaken++;
            
            spiralMap[i][0] = x;
            spiralMap[i][1] = y;
            
            int endX = x * 60 + 30;
            int endY = y * 60 + 30;
            
            Line line = new Line();
            line.changeColor("lightGray");
            line.moveTo(currentX, currentY);
            line.changeEndPosition(endX, endY);
            spiralLines.add(line);
            
            currentX = endX;
            currentY = endY;
            
            if (stepsTaken == stepSize) {
                stepsTaken = 0;
                direction = (direction + 1) % 4;
                stepCount++;
                
                if (stepCount % 2 == 0) {
                    stepSize++;
                }
            }
        }
    }

    /**
     * Dibuja el espiral visible en el canvas.
     */
    private void drawSpiral() {
        for (Line line : spiralLines) {
            line.makeVisible();
        }
    }

    /**
     * Convierte ubicación lineal a coordenadas espirales.
     * 
     * @param location Ubicación lineal
     * @return Coordenadas [x, y] en el espiral
     */
    private int[] getSpiralCoordinates(int location) {
        if (location < 0 || location >= length * length) {
            return new int[]{0, 0};
        }
        return new int[]{spiralMap[location][0], spiralMap[location][1]};
    }

    /**
     * Convierte coordenadas espirales a ubicación lineal.
     * 
     * @param x Coordenada x en el espiral
     * @param y Coordenada y en el espiral
     * @return Ubicación lineal correspondiente
     */
    private int getLinearLocation(int x, int y) {
        for (int i = 0; i < spiralMap.length; i++) {
            if (spiralMap[i][0] == x && spiralMap[i][1] == y) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Coloca una tienda en la ubicación especificada con un stock de tenges inicial.
     * 
     * @param location Ubicación en coordenadas lineales (0 a length*length-1)
     * @param tenges  Cantidad inicial de stock de la tienda
     */
    public void placeStore(int location, int tenges) { 
        if (location < 0 || location >= length * length) {
            lastOk = false;
            return;
        }
        
        int[] coords = getSpiralCoordinates(location);
        String[] colors = {"green", "magenta"}; 
        String c = colors[stores.size() % colors.length]; 
        Store s = new Store(coords[0], coords[1], c, tenges); 
        stores.add(s); 
        
        if (storeRobbedCounts.size() < stores.size()) {
            storeRobbedCounts.add(new int[1]);
        }
        
        s.makeVisible(); 
        lastOk = true; 
    }

    /**
     * Remueve una tienda de la ubicación especificada.
     * 
     * @param location Ubicación de la tienda a remover
     */
    public void removeStore(int location) {
        int[] coords = getSpiralCoordinates(location);
        Store toRemove = null;
        for (Store s : stores) {
            if (s.getX() == coords[0] && s.getY() == coords[1]) {
                toRemove = s;
                break;
            }
        }
        if (toRemove != null) {
            toRemove.makeInvisible();
            stores.remove(toRemove);
            lastOk = true;
        } else {
            lastOk = false;
        }
    }

    /**
     * Coloca un robot en la ubicación especificada.
     * 
     * @param location Ubicación donde colocar el robot
     */
    public void placeRobot(int location) { 
        if (location < 0 || location >= length * length) {
            lastOk = false;
            return;
        }
        
        int[] coords = getSpiralCoordinates(location);
        String[] colors = {"red", "black", "blue", "yellow"}; 
        String c = colors[robots.size() % colors.length]; 
        Robot r = new Robot(robots.size() + 1, coords[0], coords[1], c); 
        r.setInitialPosition(coords[0], coords[1]);
        robots.add(r); 
        r.makeVisible(); 
        lastOk = true; 
    }

    /**
     * Remueve un robot de la ubicación especificada.
     * 
     * @param location Ubicación del robot a remover
     */
    public void removeRobot(int location) {
        int[] coords = getSpiralCoordinates(location);
        Robot toRemove = null;
        for (Robot r : robots) {
            if (r.getX() == coords[0] && r.getY() == coords[1]) {
                toRemove = r;
                break;
            }
        }
        if (toRemove != null) {
            toRemove.makeInvisible();
            robots.remove(toRemove);
            lastOk = true;
        } else {
            lastOk = false;
        }
    }

    /**
     * Mueve un robot desde su ubicación actual una cantidad de metros.
     * Si el robot cae en una tienda, la roba y suma las ganancias que la tienda tenía.
     * El costo de movimiento es 1 tenge por metro movido.
     * 
     * @param location Ubicación actual del robot a mover
     * @param meters  Cantidad de metros a mover (puede ser negativo)
     */
    public void moveRobot(int location, int meters) {
        int[] coords = getSpiralCoordinates(location);
        for (Robot r : robots) {
            if (r.getX() == coords[0] && r.getY() == coords[1]) {
                int currentLinearLoc = getLinearLocation(r.getX(), r.getY());
                int newLinearLoc = (currentLinearLoc + meters) % (length * length);
                if (newLinearLoc < 0) newLinearLoc += length * length;
                
                int[] newCoords = getSpiralCoordinates(newLinearLoc);
                r.moveTo(newCoords[0], newCoords[1]);
                
                int movementCost = Math.abs(meters);
                int robotIndex = robots.indexOf(r);
                
                for (Store s : stores) {
                    if (s.getX() == newCoords[0] && s.getY() == newCoords[1] && !s.isEmpty()) {
                        int stolen = r.rob(s);
                        int netProfit = stolen - movementCost;
                        
                        if (netProfit > 0) {
                            profit += netProfit;
                        }
                        
                    
                        if (robotMovementEarnings.size() <= robotIndex) {
                            robotMovementEarnings.add(new ArrayList<Integer>());
                        }
                        robotMovementEarnings.get(robotIndex).add(netProfit);
                        
                        int storeIndex = stores.indexOf(s);
                        while (storeRobbedCounts.size() <= storeIndex) {
                            storeRobbedCounts.add(new int[1]);
                        }
                        storeRobbedCounts.get(storeIndex)[0]++;
                        
                        bar.update(profit, getMaxProfit());
                        break;
                    }
                }
                
                lastOk = true;
                return;
            }
        }
        lastOk = false;
    }

    /**
     * Reabastece todas las tiendas con su stock máximo.
     */
    public void resupplyStores() {
        for (Store s : stores) {
            s.resupply();
        }
        lastOk = true;
    }

    /**
     * Devuelve todos los robots a sus posiciones iniciales.
     */
    public void returnRobots() {
        for (Robot r : robots) {
            r.returnToInitialPosition();
        }
        lastOk = true;
    }

    /**
     * Reinicia el estado del juego: profit a 0, reabastece tiendas y devuelve robots.
     * Marca el final de un día y comienza uno nuevo.
     */
    public void reboot() {
        dailyProfits.add(profit);
        dayCount++;
        profit = 0;
        for (Store s : stores) s.resupply();
        returnRobots();
        bar.update(0, getMaxProfit());
        lastOk = true;
    }

    /**
     * Retorna el profit total acumulado por los robos.
     * 
     * @return El profit total acumulado
     */
    public int profit() {
        return profit;
    }

    /**
     * Retorna un array con información de todas las tiendas.
     * 
     * @return Array ordenado por ubicación donde cada fila contiene: [ubicación, stock_actual]
     */
    public int[][] stores() {
        int[][] arr = new int[stores.size()][2];
        for (int i = 0; i < stores.size(); i++) {
            Store s = stores.get(i);
            arr[i][0] = getLinearLocation(s.getX(), s.getY());
            arr[i][1] = s.getStock();
        }
        Arrays.sort(arr, (a, b) -> a[0] - b[0]);
        return arr;
    }

    /**
     * Retorna un array con información de todos los robots.
     * 
     * @return Array ordenado por ubicación donde cada fila contiene: [ubicación, cantidad_de_tiendas_robadas]
     */
    public int[][] robots() {
        int[][] arr = new int[robots.size()][2];
        for (int i = 0; i < robots.size(); i++) {
            Robot r = robots.get(i);
            arr[i][0] = getLinearLocation(r.getX(), r.getY());
            arr[i][1] = r.getRobbedStores();
        }
        Arrays.sort(arr, (a, b) -> a[0] - b[0]);
        return arr;
    }

    /**
     * Hace visibles todos los elementos: tiendas, robots y barra de progreso.
     */
    public void makeVisible() {
        for (Line line : spiralLines) {
            line.makeVisible();
        }
        for (Store s : stores) s.makeVisible();
        for (Robot r : robots) r.makeVisible();
        bar.makeVisible();
    }

    /**
     * Hace invisibles todos los elementos.
     */
    public void makeInvisible() {
        for (Store s : stores) s.makeInvisible();
        for (Robot r : robots) r.makeInvisible();
        bar.makeInvisible();
    }

    /**
     * Finaliza la simulación: hace invisibles todos los elementos y limpia las listas.
     */
    public void finish() {
        makeInvisible();
        stores.clear();
        robots.clear();
        profit = 0;
        dayCount = 0;
        dailyProfits.clear();
        storeRobbedCounts.clear();
        robotMovementEarnings.clear();
    }

    /**
     * Indica si la última operación fue exitosa.
     * 
     * @return true si la última operación fue exitosa, false en caso contrario
     */
    public boolean ok() {
        return lastOk;
    }

    /**
     * Calcula el profit máximo posible, que es la suma del stock máximo de todas las tiendas.
     * 
     * @return El profit máximo
     */
    private int getMaxProfit() {
        int total = 0;
        for (Store s : stores) total += s.getMaxStock();
        return total;
    }

    //  EXTENSIONES PARA EL SEGUNDO CICLO

    /**
     * EXTENSIÓN Requisito 10: Crea una ruta de seda con entrada del problema de la maratón.
     * 
     * @param storesInfo Array de tiendas [ubicación, tenges]
     * @param robotsInfo Array de robots [ubicación]
     */
    public void createExtension(int[][] storesInfo, int[][] robotsInfo) {
        finish();
        
        for (int[] store : storesInfo) {
            placeStore(store[0], store[1]);
        }
        
        for (int[] robot : robotsInfo) {
            placeRobot(robot[0]);
        }
        
        storeRobbedCounts = new ArrayList<>();
        for (int i = 0; i < stores.size(); i++) {
            storeRobbedCounts.add(new int[1]);
        }
        
        robotMovementEarnings = new ArrayList<>();
        for (int i = 0; i < robots.size(); i++) {
            robotMovementEarnings.add(new ArrayList<Integer>());
        }
        
        lastOk = true;
    }

    /**
     * EXTENSIÓN Requisito 11: Mueve robots buscando maximizar la ganancia.
     * Cada robot elige la tienda que le proporcione la mayor ganancia neta.
     */
    public void moveRobotExtension() {
        if (robots.isEmpty() || stores.isEmpty()) {
            lastOk = false;
            return;
        }
        
        for (Robot robot : robots) {
            int robotLinearLoc = getLinearLocation(robot.getX(), robot.getY());
            Store bestStore = null;
            int maxNetProfit = Integer.MIN_VALUE;
            
            for (Store store : stores) {
                if (!store.isEmpty()) {
                    int storeLinearLoc = getLinearLocation(store.getX(), store.getY());
                    int distance = Math.abs(storeLinearLoc - robotLinearLoc);
                    int netProfit = store.getStock() - distance;
                    
                    if (netProfit > maxNetProfit) {
                        maxNetProfit = netProfit;
                        bestStore = store;
                    }
                }
            }
            
            if (bestStore != null) {
                int storeLinearLoc = getLinearLocation(bestStore.getX(), bestStore.getY());
                int metersToMove = storeLinearLoc - robotLinearLoc;
                moveRobot(robotLinearLoc, metersToMove);
            }
        }
        
        lastOk = true;
    }

    /**
     * EXTENSIÓN Requisito 12: Consulta el número de veces que cada tienda ha sido desocupada.
     * 
     * @return Array ordenado por ubicación con [ubicación, contador_de_robos]
     */
    public int[][] emptiedStores() {
        int[][] result = new int[stores.size()][2];
        
        for (int i = 0; i < stores.size(); i++) {
            Store store = stores.get(i);
            int location = getLinearLocation(store.getX(), store.getY());
            int robbedCount = 0;
            
            if (i < storeRobbedCounts.size()) {
                robbedCount = storeRobbedCounts.get(i)[0];
            }
            
            result[i][0] = location;
            result[i][1] = robbedCount;
        }
        
        Arrays.sort(result, (a, b) -> a[0] - b[0]);
        return result;
    }

    /**
     * EXTENSIÓN Requisito 13: Consulta las ganancias que ha logrado cada robot en cada movimiento.
     * 
     * @return Array 2D donde cada fila representa un robot y contiene sus ganancias por movimiento
     */
    public int[][] profitPerMove() {
        int[][] result = new int[robots.size()][];
        
        for (int i = 0; i < robots.size(); i++) {
            if (i < robotMovementEarnings.size()) {
                result[i] = robotMovementEarnings.get(i).stream()
                    .mapToInt(Integer::intValue)
                    .toArray();
            } else {
                result[i] = new int[0];
            }
        }
        
        return result;
    }

    /**
     * Obtiene las ganancias diarias acumuladas.
     * 
     * @return Array con la ganancia de cada día
     */
    public int[] getDailyProfits() {
        return dailyProfits.stream().mapToInt(i -> i).toArray();
    }

    /**
     * Obtiene el número de días transcurridos.
     * 
     * @return Contador de días
     */
    public int getDayCount() {
        return dayCount;
    }

    /**
     * Reinicia completamente el contador de días y estadísticas.
     */
    public void resetDayCount() {
        dayCount = 0;
        dailyProfits.clear();
        storeRobbedCounts.clear();
        robotMovementEarnings.clear();
        reboot();
    }
    
    /**
     * Hace parpadear al robot con más ganancias
     * Solo se activa cuando se llama explícitamente a este método
     */
    public void blinkTopEarner() {
        if (robots.isEmpty()) return;
        Robot topRobot = robots.get(0);
        for (Robot robot : robots) {
            if (robot.getTotalEarnings() > topRobot.getTotalEarnings()) {
                topRobot = robot;
            }
        }
        topRobot.setBlinking(true);
    }
    
    /**
     * Detiene el parpadeo de todos los robots
     */
    public void stopAllBlinking() {
        for (Robot robot : robots) {
            robot.setBlinking(false);
        }
}
}