package silkroad;
import shapes.*;
import java.util.*;
/**
 * Tienda luchadora: solo puede ser robada por robots que tengan más ganancias que ella.
 * Tiene un triangulo azil en su base.
 * Laura Castillo y Mariana Malagón
 * 23/10/2025
 */
public class FighterStore extends Store {

    /**
     * Crea una tienda luchadora.
     * @param x coordenada x
     * @param y coordenada y
     * @param color color visual
     * @param stock dinero inicial
     */
    public FighterStore(int x, int y, String color, int stock) {
        super(x, y, color, stock);
        drawInnerShape("triangle", "blue");
    }

    /**
     * Intenta ser robada solo si el robot tiene más ganancias acumuladas.
     * @param r robot que intenta robar
     * @return cantidad robada, 0 si no puede
     */
    public int robBy(Robot r) {
        if (r.getTotalEarnings() > getStock()) {
            return robAll();
        }
        return 0;
    }
}
