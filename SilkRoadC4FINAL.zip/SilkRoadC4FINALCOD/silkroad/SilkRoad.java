package silkroad;
import shapes.*;
import java.util.*;

/**
 * Clase que representa SilkRoad, gestiona las tiendas, los robots y sus interacciones.
 * La ruta sigue un patrón en espiral cuadrado visible y los robots pierden metros al robar.
 * Permite colocar o remover tiendas y robots, mover robots para robar tiendas, y guardar y ver las ganancias.
 * Laura Castillo y Mariana Malagón
 * 16/09/2025
 */
public class SilkRoad {
    private int length;
    private ArrayList<Store> stores;
    private ArrayList<Robot> robots;
    private int profit;
    private ProgressBar bar;
    private boolean lastOk;
    private int gridSize;
    private int[][] spiralMap;
    private ArrayList<Line> spiralLines;
    private int dayCount;
    private ArrayList<Integer> dailyProfits;
    private ArrayList<int[]> storeRobbedCounts;

    /**
     * Constructor 1: Crea una nueva instancia de SilkRoad con una longitud específica (N total de casillas).
     * @param length La longitud de la ruta (N casillas).
     */
    public SilkRoad(int length) { 
        this.length = length;
        this.stores = new ArrayList<>();
        this.robots = new ArrayList<>();
        this.profit = 0;
        this.lastOk = true;
        this.bar = new ProgressBar(300, 20);
        this.spiralLines = new ArrayList<>();
        this.dayCount = 0;
        this.dailyProfits = new ArrayList<>();
        this.storeRobbedCounts = new ArrayList<>();
        this.gridSize = (int) Math.ceil(Math.sqrt(this.length));
        if (this.gridSize < 1) this.gridSize = 1;
        this.generateSpiralMap();
        this.drawSpiral();
    }

    /**
     * Constructor 2: Crea una nueva instancia de SilkRoad.
     * El tamaño N (length) se determina por la máxima ubicación entre las tiendas.
     * @param days Array de información diaria.
     */
    public SilkRoad(int[][] days) { 
        int maxLocation = 0;
        if (days != null) {
            for (int[] d : days) {
                if (d != null && d.length >= 2 && d[1] > maxLocation) {
                    maxLocation = d[1];
                }
            }
        }
        this.length = maxLocation + 1;
        this.stores = new ArrayList<>();
        this.robots = new ArrayList<>();
        this.profit = 0;
        this.lastOk = true;
        this.bar = new ProgressBar(300, 20);
        this.spiralLines = new ArrayList<>();
        this.dayCount = 0;
        this.dailyProfits = new ArrayList<>();
        this.storeRobbedCounts = new ArrayList<>();
        this.gridSize = (int) Math.ceil(Math.sqrt(this.length));
        if (this.gridSize < 1) this.gridSize = 1;
        this.generateSpiralMap();
        this.drawSpiral();
    }

    /**
     * Genera el mapa de espiral según la longitud dada.
     */
    private void generateSpiralMap() {
        spiralMap = new int[length][2]; 
        if (length <= 0) return;
        int center = gridSize / 2;
        int x = center, y = center;
        int direction = 0, stepSize = 1, stepCount = 0, stepsTaken = 0;
        int[][] dirs = {{1, 0}, {0, 1}, {-1, 0}, {0, -1}};
        spiralMap[0][0] = x;
        spiralMap[0][1] = y;
        int cx = x * 60 + 30, cy = y * 60 + 30;
        for (int i = 1; i < length; i++) {
            x += dirs[direction][0];
            y += dirs[direction][1];
            stepsTaken++;
            spiralMap[i][0] = x;
            spiralMap[i][1] = y;
            int ex = x * 60 + 30, ey = y * 60 + 30;
            Line line = new Line();
            line.changeColor("lightGray");
            line.moveTo(cx, cy);
            line.changeEndPosition(ex, ey);
            spiralLines.add(line);
            cx = ex; cy = ey;
            if (stepsTaken == stepSize) {
                stepsTaken = 0;
                direction = (direction + 1) % 4;
                stepCount++;
                if (stepCount % 2 == 0) stepSize++;
            }
        }
    }

    /**
     * Dibuja el espiral visible en el canvas.
     */
    private void drawSpiral() {
        for (Line l : spiralLines) l.makeVisible();
    }

    /**
     * Convierte ubicación lineal a coordenadas espirales.
     */
    private int[] getSpiralCoordinates(int location) {
        if (location < 0 || location >= length) return new int[]{0, 0};
        return new int[]{spiralMap[location][0], spiralMap[location][1]};
    }

    /**
     * Convierte coordenadas espirales a ubicación lineal.
     */
    private int getLinearLocation(int x, int y) {
        for (int i = 0; i < length; i++)
            if (spiralMap[i][0] == x && spiralMap[i][1] == y) return i;
        return -1;
    }

    /**
     * Coloca una tienda.
     */
    public void placeStore(int location, int tenges) { 
        if (location < 0 || location >= length) { 
            lastOk = false; 
            return; 
        }
        int[] c = getSpiralCoordinates(location);
        String color = (stores.size() % 2 == 0) ? "green" : "magenta";
        Store s = new Store(c[0], c[1], color, tenges);
        stores.add(s);
        if (storeRobbedCounts.size() < stores.size()) storeRobbedCounts.add(new int[1]);
        s.makeVisible(); 
        lastOk = true;
    }

    /**
     * Remueve una tienda.
     */
    public void removeStore(int location) {
        int[] c = getSpiralCoordinates(location);
        Store rem = null;
        for (Store s : stores) if (s.getX() == c[0] && s.getY() == c[1]) { rem = s; break; }
        if (rem != null) { 
            rem.makeInvisible(); 
            stores.remove(rem); 
            lastOk = true; 
        } 
        else lastOk = false;
    }

    /**
     * Coloca un robot.
     */
    public void placeRobot(int location) { 
        if (location < 0 || location >= length) { 
            lastOk = false; 
            return; 
        }
        int[] c = getSpiralCoordinates(location);
        String[] colors = { "black", "blue", "yellow"}; 
        String col = colors[robots.size() % colors.length];
        Robot r = new Robot(robots.size() + 1, c[0], c[1], col);
        r.setInitialPosition(c[0], c[1]);
        robots.add(r);
        r.makeVisible();
        lastOk = true;
    }

    /**
     * Remueve un robot.
     */
    public void removeRobot(int location) {
        int[] c = getSpiralCoordinates(location);
        Robot rem = null;
        for (Robot r : robots) if (r.getX() == c[0] && r.getY() == c[1]) { rem = r; break; }
        if (rem != null) { 
            rem.makeInvisible(); 
            robots.remove(rem); 
            lastOk = true; 
        } 
        else lastOk = false;
    }

    /**
     * Mueve un robot una cantidad de metros.
     */
    public void moveRobot(int location, int meters) {
        int[] c = getSpiralCoordinates(location);
        for (Robot r : robots) {
            if (r.getX() == c[0] && r.getY() == c[1]) {
                int current = getLinearLocation(r.getX(), r.getY());
                int newLoc = (current + meters) % length;
                if (newLoc < 0) newLoc += length;
                int[] newC = getSpiralCoordinates(newLoc);
                r.moveTo(newC[0], newC[1]);
                int moveCost = Math.abs(meters);
                for (Store s : stores) {
                    if (s.getX() == newC[0] && s.getY() == newC[1] && !s.isEmpty()) {
                        int stolen = r.rob(s);
                        int net = stolen - moveCost;
                        if (net > 0) profit += net;
                        r.addEarnings(net);
                        int idx = stores.indexOf(s);
                        while (storeRobbedCounts.size() <= idx) storeRobbedCounts.add(new int[1]);
                        storeRobbedCounts.get(idx)[0]++;
                        bar.update(profit, getMaxProfit());
                        break;
                    }
                }
                lastOk = true; 
                return;
            }
        }
        lastOk = false;
    }

    /**
     * Mueve robots buscando maximizar la ganancia.
     */
    public void moveRobots() { 
        if (robots.isEmpty() || stores.isEmpty()) { 
            lastOk = false; 
            return; 
        }
        for (Robot r : robots) {
            int rLoc = getLinearLocation(r.getX(), r.getY());
            Store best = null; 
            int bestProfit = Integer.MIN_VALUE;
            for (Store s : stores) {
                if (!s.isEmpty()) {
                    int sLoc = getLinearLocation(s.getX(), s.getY());
                    int dist = Math.abs(sLoc - rLoc);
                    int net = s.getStock() - dist;
                    if (net > bestProfit) { 
                        bestProfit = net; 
                        best = s; 
                    }
                }
            }
            if (best != null && bestProfit > 0) {
                int sLoc = getLinearLocation(best.getX(), best.getY());
                int move = sLoc - rLoc;
                moveRobot(rLoc, move);
            }
        }
        lastOk = true;
    }

    /**
     * Reabastece todas las tiendas.
     */
    public void resupplyStores() {
        for (Store s : stores) s.resupply();
        lastOk = true;
    }

    /**
     * Devuelve todos los robots a sus posiciones iniciales.
     */
    public void returnRobots() {
        for (Robot r : robots) r.returnToInitialPosition();
        lastOk = true;
    }

    /**
     * Reinicia el estado del juego: profit a 0, reabastece tiendas y devuelve robots.
     */
    public void reboot() {
        dailyProfits.add(profit);
        dayCount++;
        profit = 0;
        for (Store s : stores) s.resupply();
        returnRobots();
        bar.update(0, getMaxProfit());
        lastOk = true;
    }

    /**
     * Retorna el profit total acumulado.
     */
    public int profit() { 
        return profit; 
    }

    /**
     * Retorna un array con información de todas las tiendas.
     */
    public int[][] stores() {
        int[][] arr = new int[stores.size()][2];
        for (int i = 0; i < stores.size(); i++) {
            Store s = stores.get(i);
            arr[i][0] = getLinearLocation(s.getX(), s.getY());
            arr[i][1] = s.getStock();
        }
        Arrays.sort(arr, (a, b) -> a[0] - b[0]);
        return arr;
    }

    /**
     * Retorna un array con información de todos los robots.
     */
    public int[][] robots() {
        int[][] arr = new int[robots.size()][2];
        for (int i = 0; i < robots.size(); i++) {
            Robot r = robots.get(i);
            arr[i][0] = getLinearLocation(r.getX(), r.getY());
            arr[i][1] = r.getRobbedStores();
        }
        Arrays.sort(arr, (a, b) -> a[0] - b[0]);
        return arr;
    }

    /**
     * Consulta el número de veces que cada tienda ha sido desocupada.
     */
    public int[][] emptiedStores() {
        ArrayList<int[]> res = new ArrayList<>();
        for (int i = 0; i < stores.size(); i++) {
            Store s = stores.get(i);
            if (s.isEmpty()) {
                int loc = getLinearLocation(s.getX(), s.getY());
                int robbed = (i < storeRobbedCounts.size()) ? storeRobbedCounts.get(i)[0] : 0;
                if (robbed > 0) res.add(new int[]{loc, robbed});
            }
        }
        int[][] r = res.toArray(new int[0][0]);
        Arrays.sort(r, (a, b) -> a[0] - b[0]);
        return r;
    }

    /**
     * Consulta las ganancias que ha logrado cada robot en cada movimiento.
     */
    public int[][] profitPerMove() {
        int[][] result = new int[robots.size()][];
        for (int i = 0; i < robots.size(); i++) {
            List<Integer> earnings = robots.get(i).getEarningsHistory();
            result[i] = earnings.stream().mapToInt(Integer::intValue).toArray();
        }
        return result;
    }

    /**
     * Hace visibles todos los elementos.
     */
    public void makeVisible() {
        for (Line l : spiralLines) l.makeVisible();
        for (Store s : stores) s.makeVisible();
        for (Robot r : robots) r.makeVisible();
        bar.makeVisible();
    }

    /**
     * Hace invisibles todos los elementos.
     */
    public void makeInvisible() {
        for (Store s : stores) s.makeInvisible();
        for (Robot r : robots) r.makeInvisible();
        bar.makeInvisible();
    }

    /**
     * Finaliza la simulación.
     */
    public void finish() {
        makeInvisible();
        stores.clear();
        robots.clear();
        profit = 0;
        dayCount = 0;
        dailyProfits.clear();
        storeRobbedCounts.clear();
    }

    /**
     * Indica si la última operación fue exitosa.
     */
    public boolean ok() { 
        return lastOk; 
    }

    /**
     * Obtener la mayor ganancia.
     */
    private int getMaxProfit() {
        int t = 0;
        for (Store s : stores) t += s.getMaxStock();
        return t;
    }

    /**
     * Crea una ruta de seda con la entrada del problema de la maratón.
     * @param maratonIn Array de operaciones: [[tipo, locación, valor(si es tienda)]]
     */
    public void createExtension(int[][] maratonIn) {
        finish();
        int maxLocation = 0;
        if (maratonIn != null)
            for (int[] op : maratonIn)
                if (op.length >= 2 && op[1] > maxLocation)
                    maxLocation = op[1];
        this.length = maxLocation + 1;
        this.gridSize = (int) Math.ceil(Math.sqrt(this.length));
        if (this.gridSize < 1) this.gridSize = 1;
        for (int[] op : maratonIn) {
            int type = op[0], loc = op[1];
            if (type == 1) placeRobot(loc);
            else if (type == 2 && op.length >= 3) placeStore(loc, op[2]);
        }
        storeRobbedCounts = new ArrayList<>();
        for (int i = 0; i < stores.size(); i++) storeRobbedCounts.add(new int[1]);
        lastOk = true;
    }

    /**
     * Obtiene las ganancias diarias acumuladas.
     */
    public int[] getDailyProfits() {
        return dailyProfits.stream().mapToInt(i -> i).toArray();
    }

    /**
     * Obtiene el número de días transcurridos.
     */
    public int getDayCount() {
        return dayCount;
    }

    /**
     * Reinicia completamente el contador de días y estadísticas.
     */
    public void resetDayCount() {
        dayCount = 0;
        dailyProfits.clear();
        storeRobbedCounts.clear();
        reboot();
    }

    /**
     * Hace parpadear al robot con más ganancias.
     */
    public void blinkTopEarner() {
        if (robots.isEmpty()) return;
        Robot top = robots.get(0);
        for (Robot r : robots)
            if (r.getTotalEarnings() > top.getTotalEarnings()) top = r;
        top.setBlinking(true);
    }

    /**
     * Detiene el parpadeo de todos los robots.
     */
    public void stopAllBlinking() {
        for (Robot r : robots) r.setBlinking(false);
    }
    
    //Ciclo 4
    /**
     * Coloca un robot teniendo en cuenta la locación y el tipo.
     */
    public void placeRobot(int location, String type) {
        if (location < 0 || location >= length) return;
        int[] c = getSpiralCoordinates(location);
        Robot r;
        switch (type.toLowerCase()) {
            case "neverback":
                r = new NeverBackRobot(robots.size() + 1, c[0], c[1], "yellow");
                break;
            case "tender":
                r = new TenderRobot(robots.size() + 1, c[0], c[1], "red");
                break;
            default:
                r = new Robot(robots.size() + 1, c[0], c[1], "green");
        }
        r.setInitialPosition(c[0], c[1]);
        robots.add(r);
        r.makeVisible();
        lastOk = true;
     }
    
    /**
     * Coloca una tienda teniendo en cuenta la locación y el tipo.
     */
    public void placeStore(int location, int tenges, String type) {
        if (location < 0 || location >= length) return;
        int[] c = getSpiralCoordinates(location);
        Store s;
        switch (type.toLowerCase()) {
            case "autonomous":
                s = new AutonomousStore(c[0], c[1], "green", tenges);
                break;
            case "fighter":
                s = new FighterStore(c[0], c[1], "magenta", tenges);
                break;
            case "protected":
                s = new ProtectedStore(c[0], c[1], "red", tenges);
                break;
            default:
                s = new Store(c[0], c[1], "yellow", tenges);
        }
        stores.add(s);
        s.makeVisible();
        lastOk = true;
    }

}
