package silkroad;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Pruebas unitarias de los métodos desarrollados en el ciclo 4.
 * Laura Castillo y Mariana Malagón
 */
public class SilkRoadC4Test {

    @Test
    public void testPlaceRobotAndStore() {
        SilkRoad road = new SilkRoad(25);
        road.placeRobot(5, "tender");
        road.placeStore(10, 50, "fighter");
        assertTrue("La creación de robot y tienda debería ser exitosa", road.ok());
    }

    @Test
    public void testTenderRobotRobaMitad() {
        Store tienda = new Store(0, 0, "blue", 100);
        TenderRobot robot = new TenderRobot(1, 0, 0, "red");
        int robado = robot.rob(tienda);
        assertEquals("El TenderRobot debe robar la mitad del dinero", 50, robado);
    }

    @Test
    public void testNeverBackRobotNoRetrocede() {
        NeverBackRobot nb = new NeverBackRobot(1, 5, 5, "red");
        nb.moveTo(3, 5);
        assertEquals("No debe haberse movido hacia atrás", 5, nb.getX());
    }

    @Test
    public void testProtectedStoreSoloUnaVez() {
        ProtectedStore ps = new ProtectedStore(0, 0, "red", 40);
        int first = ps.robAll();
        int second = ps.robAll();
        assertEquals("Debe permitir solo un robo", 40, first);
        assertEquals("El segundo robo no debe dar nada", 0, second);
    }

    @Test
    public void testAutonomousStoreSeMueve() {
        boolean moved = false;
        for (int i = 0; i < 5; i++) {
            AutonomousStore as = new AutonomousStore(2, 2, "green", 30);
            if (as.getX() != 2 || as.getY() != 2) {
                moved = true;
                break;
            }
        }
        assertTrue("La tienda autónoma debería moverse al menos en uno de los intentos", moved);
    }
}
