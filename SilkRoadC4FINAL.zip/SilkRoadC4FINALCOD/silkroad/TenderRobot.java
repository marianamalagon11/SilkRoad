package silkroad;
import shapes.*;
import java.util.*;
/**
 * Robot Tender: solo roba la mitad del dinero de las tiendas.
 * Tiene un circulo rojo en su cuerpo.
 * Laura Castillo y Mariana Malagón
 * 23/10/2025
 */
public class TenderRobot extends Robot {

    /**
     * Crea un robot Tender.
     * @param id identificador
     * @param x coordenada x
     * @param y coordenada y
     * @param color color visual
     */
    public TenderRobot(int id, int x, int y, String color) {
        super(id, x, y, color);
        drawInnerShape("triangle", "red");
    }

    /**
     * Roba solo la mitad del dinero de una tienda.
     * @param s tienda objetivo
     * @return cantidad robada
     */
    @Override
    public int rob(Store s) {
        int half = s.getStock() / 2;
        return s.take(half);
    }

}
