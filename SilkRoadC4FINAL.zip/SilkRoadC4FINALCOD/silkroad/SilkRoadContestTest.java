package silkroad;
import shapes.*;
import java.util.*;
/**
 * SilkRoadContestTest.java
 *
 * Pruebas unitarias para la clase SilkRoadContest.
 * Autor: Laura Castillo y Mariana Malagón
 * 05/10/2025
 */
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SilkRoadContestTest {

    @Test
    public void testEmptyDays() {
        int[][] days = new int[0][];
        int[] result = SilkRoadContest.solve(days);
        assertEquals(0, result.length);
    }

    @Test
    public void testOnlyRobots() {
        int[][] days = {
            {1, 3},
            {1, 5}
        };
        int[] expected = {0, 0};
        assertArrayEquals(expected, SilkRoadContest.solve(days));
    }

    @Test
    public void testOnlyStores() {
        int[][] days = {
            {2, 5, 10},
            {2, 8, 15}
        };
        int[] expected = {0, 0};
        assertArrayEquals(expected, SilkRoadContest.solve(days));
    }

    @Test
    public void testOneRobotOneStore() {
        int[][] days = {
            {1, 3},
            {2, 6, 10}
        };
        int[] expected = {0, 7};
        assertArrayEquals(expected, SilkRoadContest.solve(days));
    }

    @Test
    public void testMultipleRobotsStores() {
        int[][] days = {
            {1, 0},
            {2, 5, 10},
            {1, 7},
            {2, 9, 6}
        };
        int[] expected = {0, 5, 8, 10};
        assertArrayEquals(expected, SilkRoadContest.solve(days));
    }

    @Test
    public void testNegativeIntermediateProfit() {
        int[][] days = {
            {1, 0},
            {2, 2, 1},
            {2, 5, 10}
        };
        int[] result = SilkRoadContest.solve(days);
        assertEquals(6, result[2]);
    }

    @Test
    public void testSimulationNoCrash() {
        int[][] days = {
            {1, 2},
            {2, 4, 10}
        };
        assertDoesNotThrow(() -> SilkRoadContest.simulate(days, false));
    }
}
