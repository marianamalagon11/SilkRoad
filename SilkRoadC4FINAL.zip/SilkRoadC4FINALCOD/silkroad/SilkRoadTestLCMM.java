package silkroad;
import shapes.*;
import java.util.*;
/**
 * SilkRoadTestLCMM.java
 *
 * Pruebas unitarias para la clase SilkRoad (Ciclo 2).
 * Laura Castillo y Mariana Malagón
 * 04/10/2025
 */
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class SilkRoadTestLCMM {

    private SilkRoad road;

    @Before
    public void setUp() {
        road = new SilkRoad(20);
    }

    @Test
    public void testConstructorWithLength() {
        SilkRoad newRoad = new SilkRoad(10);
        newRoad.placeStore(5, 50);
        assertTrue("Debe permitir colocar tienda dentro del rango", newRoad.ok());
    }

    @Test
    public void testConstructorWithDays() {
        int[][] data = {
            {2, 3, 40},
            {1, 5},
            {2, 10, 60}
        };
        SilkRoad newRoad = new SilkRoad(data);
        newRoad.placeStore(10, 20);
        assertTrue("Debe permitir ubicación máxima (10)", newRoad.ok());
    }

    @Test
    public void testPlaceStore() {
        road.placeStore(5, 30);
        assertTrue(road.ok());
        assertEquals(1, road.stores().length);
    }

    @Test
    public void testRemoveStore() {
        road.placeStore(5, 30);
        road.removeStore(5);
        assertTrue(road.ok());
        assertEquals(0, road.stores().length);
    }

    @Test
    public void testPlaceRobot() {
        road.placeRobot(3);
        assertTrue(road.ok());
        assertEquals(1, road.robots().length);
    }

    @Test
    public void testRemoveRobot() {
        road.placeRobot(3);
        road.removeRobot(3);
        assertTrue(road.ok());
        assertEquals(0, road.robots().length);
    }

    @Test
    public void testMoveRobotValid() {
        road.placeStore(10, 20);
        road.placeRobot(5);
        road.moveRobot(5, 5);
        assertTrue(road.ok());
    }

    @Test
    public void testMoveRobotInvalid() {
        road.placeRobot(2);
        road.moveRobot(50, 3);
        assertFalse(road.ok());
    }

    @Test
    public void testMoveRobotsSimple() {
        road.placeRobot(0);
        road.placeStore(2, 10);
        road.moveRobots();
        assertTrue(road.ok());
    }

    @Test
    public void testMoveRobotsNoStores() {
        road.placeRobot(0);
        road.moveRobots();
        assertFalse(road.ok());
    }

    @Test
    public void testResupplyStores() {
        road.placeStore(2, 10);
        road.placeRobot(0);
        road.moveRobots();
        road.resupplyStores();
        assertTrue(road.ok());
    }

    @Test
    public void testReturnRobots() {
        road.placeRobot(0);
        road.moveRobot(0, 5);
        road.returnRobots();
        assertTrue(road.ok());
    }

    @Test
    public void testReboot() {
        road.placeStore(2, 10);
        road.placeRobot(0);
        road.moveRobots();
        road.reboot();
        assertEquals(0, road.profit());
    }

    @Test
    public void testProfit() {
        road.placeStore(2, 10);
        road.placeRobot(0);
        road.moveRobots();
        assertTrue(road.profit() >= 0);
    }

    @Test
    public void testStores() {
        road.placeStore(5, 15);
        int[][] s = road.stores();
        assertEquals(5, s[0][0]);
    }

    @Test
    public void testRobots() {
        road.placeRobot(3);
        int[][] r = road.robots();
        assertEquals(3, r[0][0]);
    }

    @Test
    public void testEmptiedStores() {
        road.placeStore(2, 10);
        road.placeRobot(0);
        road.moveRobots();
        int[][] e = road.emptiedStores();
        assertTrue(e.length >= 0);
    }

    @Test
    public void testProfitPerMoveBasic() {
        road.placeStore(2, 10);
        road.placeRobot(0);
        road.moveRobots();
        int[][] p = road.profitPerMove();
        assertNotNull(p);
    }

    @Test
    public void testProfitPerMoveEmpty() {
        int[][] p = road.profitPerMove();
        assertEquals(0, p.length);
    }

    @Test
    public void testMakeVisible() {
        road.makeVisible();
        assertTrue(true);
    }

    @Test
    public void testMakeInvisible() {
        road.makeInvisible();
        assertTrue(true);
    }

    @Test
    public void testFinish() {
        road.placeStore(2, 10);
        road.placeRobot(0);
        road.finish();
        assertEquals(0, road.stores().length);
        assertEquals(0, road.robots().length);
    }

    @Test
    public void testOk() {
        road.placeStore(2, 10);
        assertTrue(road.ok());
    }

    @Test
    public void testCreateExtension() {
        int[][] data = {{1, 2}, {2, 3, 10}};
        road.createExtension(data);
        assertTrue(road.ok());
    }
}
