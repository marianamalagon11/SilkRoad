package silkroad;
import shapes.*;
import java.util.*;
/**
 * Robot NeverBack: nunca se devuelve (no se mueve hacia atrás).
 * Tiene un circulo rojo en su cuerpo
 * Laura Castillo y Mariana Malagón
 * 23/10/2025
 */
public class NeverBackRobot extends Robot {

    /**
     * Crea un robot NeverBack.
     * @param id identificador
     * @param x coordenada x
     * @param y coordenada y
     * @param color color visual
     */
    public NeverBackRobot(int id, int x, int y, String color) {
        super(id, x, y, color);
        drawInnerShape("circle","red");
    }

    /**
     * Evita que el robot se mueva hacia atrás.
     */
    @Override
    public void moveTo(int newX, int newY) {
        if (newX < getX()) return;
        super.moveTo(newX, newY);
    }
}
