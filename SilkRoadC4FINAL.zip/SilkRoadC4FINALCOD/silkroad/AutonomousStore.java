package silkroad;
import shapes.*;
import java.util.*;
import java.util.Random;

/**
 * Tienda autónoma que decide su propia ubicación al crearse.
 * Se reubica en una posición aleatoria cercana al lugar inicial.
 * Tiene un circulo azul dentro de su base.
 * Laura Castillo y Mariana Malagón
 * 23/10/2025
 */
public class AutonomousStore extends Store {

    /**
     * Crea una tienda autónoma que se posiciona aleatoriamente.
     * @param x coordenada x inicial
     * @param y coordenada y inicial
     * @param color color visual
     * @param stock dinero disponible
     */
    public AutonomousStore(int x, int y, String color, int stock) {
        super(x, y, color, stock);
        moveToRandomPosition();
        drawInnerShape("circle", "blue");
    }

    /**
     * Cambia la posición a una ubicación aleatoria cercana.
     */
    private void moveToRandomPosition() {
        Random r = new Random();
        int dx = r.nextInt(5) - 2;
        int dy = r.nextInt(5) - 2;
        moveTo(getX() + dx, getY() + dy);
    }

}
