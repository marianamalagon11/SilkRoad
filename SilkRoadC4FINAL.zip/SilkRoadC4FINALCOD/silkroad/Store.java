package silkroad;
import shapes.*;
import java.util.*;
/**
 * Clase que representa una tienda en el mundo SilkRoad.
 * Cada tienda tiene una ubicación, color, stock actual y stock máximo.
 * Visualmente está compuesta por un rectángulo (base) y un triángulo (techo).
 * Laura Castillo y Mariana Malagón
 * 16/09/2025
 */
public class Store {
    private int x, y;
    private String color;
    private int stock;
    private int maxStock;
    protected Rectangle base;
    protected Triangle roof;
    private ShapeG innerShape;

    

    /**
     * Constructor que crea una nueva tienda en la ubicación especificada.
     * 
     * @param x      coordenada x de la tienda en el espiral
     * @param y      coordenada y de la tienda en el espiral
     * @param color  color de la tienda
     * @param stock  cantidad inicial de stock, también establece el stock máximo
     */
    public Store(int x, int y, String color, int stock) {
        this.x = x;
        this.y = y;
        this.color = color;
        this.stock = stock;
        this.maxStock = stock;

        int posX = x * 60 + 30;
        int posY = y * 60 + 30;

        base = new Rectangle();
        base.changeColor(color);
        base.changeSize(40, 40);
        base.moveTo(posX - 20, posY - 20);

        roof = new Triangle();
        roof.changeColor(color);
        roof.changeSize(20, 40);
        roof.moveTo(posX, posY - 40);
    }

    /**
     * Reabastece la tienda con su stock máximo.
     */
    public void resupply() {
        stock = maxStock;
        updateAppearance();
    }

    /**
     * Roba todo el stock disponible de la tienda.
     * 
     * @return la cantidad de stock robado
     */
    public int robAll() {
        int stolen = stock;
        stock = 0;
        updateAppearance();
        return stolen;
    }

    /**
     * Actualiza la apariencia visual de la tienda según su estado.
     * Las tiendas vacías se muestran en gris.
     */
    public void updateAppearance() {
        if (isEmpty()) {
            base.changeColor("gray");
            roof.changeColor("gray");
        } else {
            base.changeColor(color);
            roof.changeColor(color);
        }
    }

    /**
     * Hace visible la tienda.
     */
    public void makeVisible() {
        base.makeVisible();
        roof.makeVisible();
        if (innerShape != null) innerShape.makeVisible();
    }

    /**
     * Hace invisible la tienda.
     */
    public void makeInvisible() {
        base.makeInvisible();
        roof.makeInvisible();
        if (innerShape != null) innerShape.makeInvisible();
    }

    /**
     * Obtiene la coordenada x de la tienda en el espiral.
     * 
     * @return la coordenada x
     */
    public int getX() { 
        return x; 
    }
    
    /**
     * Obtiene la coordenada y de la tienda en el espiral.
     * 
     * @return la coordenada y
     */
    public int getY() { 
        return y; 
    }
    
    /**
     * Obtiene el stock actual de la tienda.
     * 
     * @return el stock actual
     */
    public int getStock() { 
        return stock; 
    }
    
    /**
     * Obtiene el stock máximo de la tienda.
     * 
     * @return el stock máximo
     */
    public int getMaxStock() { 
        return maxStock; 
    }
    
    /**
     * Verifica si la tienda está sin stock.
     * 
     * @return true si la tienda está vacía, false en caso contrario
     */
    public boolean isEmpty() { 
        return stock <= 0; 
    }

    /**
     * Calcula la ubicación de la tienda basada en el tamaño del "mundo".
     * 
     * @param length el tamaño del mundo (ancho/alto)
     * @return la ubicación lineal calculada como y * length + x
     */
    public int getLocation(int length) {
        return y * length + x;
    }
    
    /**
     * Mueve la tienda a una nueva posición en el espiral.
     * @param newX nueva coordenada x
     * @param newY nueva coordenada y
     */
    public void moveTo(int newX, int newY) {
        this.x = newX;
        this.y = newY;
        if (base != null) base.moveTo(newX * 60 + 30 - 15, newY * 60 + 30 - 10);
        if (roof != null) roof.moveTo(newX * 60 + 30 - 15, newY * 60 + 30 - 25);
        if (innerShape != null) innerShape.moveTo(newX * 60 + 30 - 15, newY * 60 + 30 - 10);
        
    }
        
     /**
     * Permite tomar una cantidad parcial de dinero del stock de la tienda.
     * @param amount cantidad a tomar
     * @return cantidad realmente tomada
     */
    public int take(int amount) {
        if (amount <= 0) return 0;
        if (stock >= amount) {
            stock -= amount;
            updateAppearance();
            return amount;
        } else {
            int taken = stock;
            stock = 0;
            updateAppearance();
            return taken;
        }
    }
    
    /**
     * Dibuja una figura distintiva sobre la base de la tienda.
     * @param shape "circle", "triangle" o "square"
     * @param color color de la figura
     */
    protected void drawInnerShape(String shape, String color) {
        int baseX = x * 60 + 30 - 8;
        int baseY = y * 60 + 30 - 8;
    
        if (shape.equalsIgnoreCase("circle")) {
            innerShape = new Circle();
            innerShape.changeColor("blue");
            innerShape.changeSize(12);
            innerShape.moveTo(baseX, baseY);
        } else if (shape.equalsIgnoreCase("triangle")) {
            innerShape = new Triangle();
            innerShape.changeColor("blue");
            innerShape.changeSize(14, 14);
            innerShape.moveTo(baseX, baseY);
        } else if (shape.equalsIgnoreCase("rectangle")) {
            innerShape = new Rectangle();
            innerShape.changeColor("blue");
            innerShape.changeSize(10, 10);
            innerShape.moveTo(baseX, baseY);
        }
    }


}
