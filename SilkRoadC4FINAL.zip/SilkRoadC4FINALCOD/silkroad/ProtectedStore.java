package silkroad;
import shapes.*;
import java.util.*;
/**
 * Tienda protegida: solo puede ser robada una vez.
 * Tiene un cuadrado azul en su base.
 * Laura Castillo y Mariana Malagón
 * 23/10/2025
 */
public class ProtectedStore extends Store {
    private boolean robbedOnce;

    /**
     * Crea una tienda protegida.
     * @param x coordenada x
     * @param y coordenada y
     * @param color color visual
     * @param stock dinero inicial
     */
    public ProtectedStore(int x, int y, String color, int stock) {
        super(x, y, color, stock);
        this.robbedOnce = false;
        drawInnerShape("rectangle", "blue");
    }

    /**
     * Solo puede ser robada una vez.
     * @return cantidad robada o 0 si ya fue robada
     */
    @Override
    public int robAll() {
        if (!robbedOnce && !isEmpty()) {
            robbedOnce = true;
            return super.robAll();
        }
        return 0;
    }
}
