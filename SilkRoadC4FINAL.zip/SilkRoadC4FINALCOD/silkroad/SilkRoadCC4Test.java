package silkroad;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Pruebas colectivas del simulador SilkRoad.
 * Se basan en los casos definidos en el protocolo común.
 * Laura Castillo y Mariana Malagón
 */
public class SilkRoadCC4Test {

    @Test
    public void testMovimientoRobotGeneraGanancia() {
        SilkRoad road = new SilkRoad(20);
        road.placeStore(5, 40);
        road.placeRobot(0);
        road.moveRobot(0, 5);
        assertTrue("Debe haber ganancias positivas después del movimiento", road.profit() > 0);
    }

    @Test
    public void testResupplyYReturnResetean() {
        SilkRoad road = new SilkRoad(15);
        road.placeStore(2, 30);
        road.placeRobot(2);
        road.moveRobot(2, 3);
        road.reboot();
        assertEquals("Después del reinicio el profit debe ser 0", 0, road.profit());
    }

    @Test
    public void testMoveRobotsAutoDecision() {
        SilkRoad road = new SilkRoad(25);
        road.placeStore(10, 50);
        road.placeRobot(5);
        road.moveRobots();
        assertTrue("La operación automática debe ser exitosa", road.ok());
    }
}
