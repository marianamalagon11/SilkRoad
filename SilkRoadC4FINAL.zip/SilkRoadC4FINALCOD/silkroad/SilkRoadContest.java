package silkroad;
import shapes.*;
import java.util.*;
import java.util.*;

/**
 * Clase SilkRoadContest.
 * Ofrece métodos estáticos para solucionar el problema de la maratón.
 * Laura Castillo y Mariana Malagón
 * 02/10/2025
 */
public class SilkRoadContest {

    /**
     * Clase auxiliar que representa un buen movimiento entre un robot y una tienda.
     */
    private static class OptimalMove {
        int robotIndex;
        int storeIndex;
        int netProfit;
        int metersToMove;
        int robotLocation;
        int storeLocation;

        public OptimalMove(int ri, int si, int p, int m, int rLoc, int sLoc) {
            this.robotIndex = ri;
            this.storeIndex = si;
            this.netProfit = p;
            this.metersToMove = m;
            this.robotLocation = rLoc;
            this.storeLocation = sLoc;
        }
    }

    /**
     * Calcula las ganancias máximas diarias de la maratón.
     * @param days Arreglo con las operaciones diarias: tipo (1=robot, 2=tienda), ubicación y valor si aplica.
     * @return Arreglo con las ganancias máximas acumuladas por día.
     */
    public static int[] solve(int[][] days) {
        if (days == null || days.length == 0) {
            return new int[0];
        }

        List<int[]> currentStores = new ArrayList<>();
        List<int[]> currentRobots = new ArrayList<>();
        List<Integer> dailyProfits = new ArrayList<>();

        for (int[] op : days) {
            int type = 0;
            int location = -1;
            int tenges = 0;

            if (op.length >= 1) {
                type = op[0];
            }
            if (op.length >= 2) {
                location = op[1];
            }
            if (op.length >= 3) {
                tenges = op[2];
            }

            if (type == 1) {
                int[] robotData = {location};
                currentRobots.add(robotData);
            } else if (type == 2) {
                int[] storeData = {location, tenges};
                currentStores.add(storeData);
            }

            int maxProfit = calculateMaxProfit(currentStores, currentRobots);
            dailyProfits.add(maxProfit);
        }

        int[] result = new int[dailyProfits.size()];
        for (int i = 0; i < dailyProfits.size(); i++) {
            result[i] = dailyProfits.get(i);
        }
        return result;
    }

    /**
     * Calcula la ganancia máxima probando todas las combinaciones posibles.
     */
    private static int calculateMaxProfit(List<int[]> stores, List<int[]> robots) {
        if (stores.isEmpty() || robots.isEmpty()) {
            return 0;
        }

        int[] best = {0};
        boolean[] used = new boolean[stores.size()];
        int[] robotPos = new int[robots.size()];

        for (int i = 0; i < robots.size(); i++) {
            robotPos[i] = robots.get(i)[0];
        }

        tryAllAssignments(stores, robotPos, used, 0, best);
        return best[0];
    }

    /**
     * Explora recursivamente todas las combinaciones robot-tienda.
     */
    private static void tryAllAssignments(List<int[]> stores, int[] robotPos, boolean[] used, int currentProfit, int[] bestProfit) {
        if (currentProfit > bestProfit[0]) {
            bestProfit[0] = currentProfit;
        }

        for (int s = 0; s < stores.size(); s++) {
            if (!used[s]) {
                int storePos = stores.get(s)[0];
                int storeVal = stores.get(s)[1];

                for (int r = 0; r < robotPos.length; r++) {
                    int distance = Math.abs(storePos - robotPos[r]);
                    int profit = storeVal - distance;

                    int oldPos = robotPos[r];
                    used[s] = true;
                    robotPos[r] = storePos;

                    tryAllAssignments(stores, robotPos, used, currentProfit + profit, bestProfit);

                    used[s] = false;
                    robotPos[r] = oldPos;
                }
            }
        }
    }

    /**
     * Simula la solución óptima día a día mostrando la ejecución.
     * @param days Arreglo de operaciones (robots y tiendas).
     * @param slow Si es true, incluye pausas visuales.
     */
    public static void simulate(int[][] days, boolean slow) {
        if (days == null || days.length == 0) return;

        SilkRoad road = new SilkRoad(days);
        if (slow) {
            road.makeVisible();
        }

        List<int[]> stores = new ArrayList<>();
        List<int[]> robots = new ArrayList<>();
        final int DELAY = 400;

        for (int[] op : days) {
            road.finish();

            int type = 0;
            int location = -1;
            int tenges = 0;

            if (op.length >= 1) {
                type = op[0];
            }
            if (op.length >= 2) {
                location = op[1];
            }
            if (op.length >= 3) {
                tenges = op[2];
            }

            if (type == 1) {
                int[] robotData = {location};
                robots.add(robotData);
                road.placeRobot(location);
            } else if (type == 2) {
                int[] storeData = {location, tenges};
                stores.add(storeData);
                road.placeStore(location, tenges);
            }

            List<OptimalMove> moves = getOptimalMovesForSimulation(stores, robots);

            for (OptimalMove m : moves) {
                road.moveRobot(m.robotLocation, m.metersToMove);
                if (slow) {
                    Canvas.getCanvas().wait(DELAY);
                }
            }

            road.reboot();
        }
    }

    /**
     * Obtiene los movimientos óptimos de la simulación de forma codiciosa.
     */
    private static List<OptimalMove> getOptimalMovesForSimulation(List<int[]> stores, List<int[]> robots) {
        List<OptimalMove> moves = new ArrayList<>();
        if (stores.isEmpty() || robots.isEmpty()) {
            return moves;
        }

        boolean[] used = new boolean[stores.size()];
        int[] robotPos = new int[robots.size()];

        for (int i = 0; i < robots.size(); i++) {
            robotPos[i] = robots.get(i)[0];
        }

        boolean found = true;
        while (found) {
            int bestR = -1;
            int bestS = -1;
            int bestProfit = 0;
            found = false;

            for (int r = 0; r < robots.size(); r++) {
                for (int s = 0; s < stores.size(); s++) {
                    if (!used[s]) {
                        int storePos = stores.get(s)[0];
                        int storeVal = stores.get(s)[1];
                        int distance = Math.abs(storePos - robotPos[r]);
                        int profit = storeVal - distance;

                        if (profit > bestProfit) {
                            bestProfit = profit;
                            bestR = r;
                            bestS = s;
                            found = true;
                        }
                    }
                }
            }

            if (found && bestR != -1 && bestS != -1) {
                int robotLoc = robotPos[bestR];
                int storeLoc = stores.get(bestS)[0];
                int meters = storeLoc - robotLoc;

                OptimalMove move = new OptimalMove(bestR, bestS, bestProfit, meters, robotLoc, storeLoc);
                moves.add(move);
                used[bestS] = true;
                robotPos[bestR] = storeLoc;
            }
        }

        return moves;
    }
}
