package silkroad;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Scanner;

/**
 * Pruebas de aceptación: demuestran el funcionamiento completo del proyecto.
 * Incluyen esperas visibles y preguntas de aceptación del usuario.
 * Laura Castillo y Mariana Malagón
 */
public class SilkRoadATest {

    /**
     * Método auxiliar para pausas y validación visual por parte del usuario.
     */
    private boolean esperarYConfirmar(String mensaje) {
        System.out.println("\nESPERA NECESARIA");
        System.out.println(mensaje);
        System.out.println("¿Aceptas el resultado mostrado en pantalla? s para si, n para no (s/n): ");
        Scanner sc = new Scanner(System.in);
        String respuesta = sc.nextLine().toLowerCase();
        return respuesta.equals("s") || respuesta.equals("si");
    }

    /**
     * Prueba de aceptación 1:
     * Simulación básica del sistema con tiendas y robots de diferentes tipos.
     * Incluye verificación visual y aceptación del usuario.
     */
    @Test
    public void testAceptacionSimulacionBasica() {
        SilkRoad road = new SilkRoad(30);

        road.placeStore(4, 100, "normal");
        road.placeStore(10, 120, "protected");
        road.placeStore(15, 190, "fighter");
        road.placeStore(20, 200, "autonomous");

        road.placeRobot(0, "normal");
        road.placeRobot(5, "tender");
        road.placeRobot(15, "neverback");

        road.makeVisible();
        road.moveRobots();
        road.reboot();

        boolean aceptado = esperarYConfirmar(
            "Mira el movimiento de los robots y las tiendas."
            + "\nLuego de la simulación, las tiendas deben reabastecerse y los robots volver al inicio."
        );

        assertTrue("El sistema debe finalizar correctamente", road.ok());
        assertTrue("Debe existir una ganancia no negativa", road.profit() >= 0);
        assertTrue("El usuario debe aceptar el resultado visual", aceptado);

        System.out.println("Simulación básica aceptada por el usuario. Ganancia total(debe ser 0 porque se reinició: " + road.profit());
    }

    /**
     * Prueba de aceptación 2:
     * Simulación tipo maratón que prueba la integración completa.
     * Incluye revisión visual de ganancias y confirmación del usuario.
     */
    @Test
    public void testAceptacionMaraton() {
        int[][] datos = {
            {2, 5, 40},
            {1, 0},
            {2, 10, 60},  
            {1, 15},     
            {2, 20, 80}, 
            {1, 25} 
        };

        SilkRoadContest.simulate(datos, false);
        int[] ganancias = SilkRoadContest.solve(datos);

        boolean aceptado = esperarYConfirmar(
            "Se ejecutó la simulación tipo maratón.\n"
            + "Mira las ganancias progresivas y los movimientos automáticos.\n"
            + "El comportamiento y los resultados son coherentes?"
        );

        assertNotNull("Debe devolverse un arreglo de ganancias", ganancias);
        assertTrue("Debe haber ganancias positivas", ganancias[ganancias.length - 1] > 0);
        assertTrue("El usuario debe aceptar la simulación", aceptado);

        System.out.println("Maratón completada con éxito. Ganancia final: " + ganancias[ganancias.length - 1]);
    }
}
