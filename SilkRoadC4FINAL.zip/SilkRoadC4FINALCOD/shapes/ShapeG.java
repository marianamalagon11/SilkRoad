package shapes;

/**
 * Clase base abstracta que define el contrato de métodos de movimiento, cambio de tamaño
 * y visualización para todas las figuras geométricas.
 */
public abstract class ShapeG {
    
    /**
     * Mueve el objeto a una nueva posición especificada.
     * @param newX la nueva coordenada x a la que mover el objeto
     * @param newY la nueva coordenada y a la que mover el objeto
     */
    public abstract void moveTo(int newX, int newY);
    
    /**
     * Hace visible la figura.
     */
    public abstract void makeVisible();

    /**
     * Hace invisible la figura.
     */
    public abstract void makeInvisible();

    /**
     * Cambia el color de la figura.
     * @param newColor el nuevo color
     */
    public abstract void changeColor(String newColor);
    
    /**
     * Cambia el tamaño de la figura (versión de un solo parámetro, e.g., diámetro).
     * @param size el nuevo tamaño
     */
    public abstract void changeSize(int size);

    /**
     * Cambia el tamaño de la figura (versión de dos parámetros, e.g., ancho y alto).
     * @param size1 el primer parámetro de tamaño
     * @param size2 el segundo parámetro de tamaño
     */
    public abstract void changeSize(int size1, int size2);
}