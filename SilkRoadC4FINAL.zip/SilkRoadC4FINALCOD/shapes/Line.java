package shapes;
import java.awt.geom.Line2D;

/**
 * Clase que representa una línea para dibujar el espiral
 * @author Laura Castillo y Mariana Malagón
 * @version 16/09/2025
 */
public class Line extends ShapeG {
    private int xStart, yStart, xEnd, yEnd;
    private String color;
    private boolean isVisible;

    /**
     * Constructor que crea una nueva línea.
     */
    public Line() {
        xStart = 0;
        yStart = 0;
        xEnd = 0;
        yEnd = 0;
        color = "gray";
        isVisible = false;
    }

    /**
     * Implementación requerida por el contrato de ShapeG (sobrecarga de un parámetro).
     * En Line, el "tamaño" se controla mediante los puntos finales, por lo que este
     * método se deja sin funcionalidad específica.
     * @param size El parámetro de tamaño (se ignora).
     */
    @Override
    public void changeSize(int size) {
    }

    /**
     * Implementación requerida por el contrato de ShapeG (sobrecarga de dos parámetros).
     * En Line, el "tamaño" se controla mediante los puntos finales, por lo que este
     * método se deja sin funcionalidad específica.
     * @param size1 El primer parámetro de tamaño (se ignora).
     * @param size2 El segundo parámetro de tamaño (se ignora).
     */
    @Override
    public void changeSize(int size1, int size2) {
    }

    /**
     * Cambia el color de la línea.
     *
     * @param newColor nuevo color de la línea
     */
    @Override
    public void changeColor(String newColor) {
        color = newColor;
        if (isVisible) draw();
    }

    /**
     * Cambia la posición final de la línea.
     *
     * @param newXEnd nueva coordenada x final
     * @param newYEnd nueva coordenada y final
     */
    public void changeEndPosition(int newXEnd, int newYEnd) {
        xEnd = newXEnd;
        yEnd = newYEnd;
        if (isVisible) draw();
    }

    /**
     * Mueve la línea a una nueva posición inicial.
     *
     * @param newX nueva coordenada x inicial
     * @param newY nueva coordenada y inicial
     */
    @Override
    public void moveTo(int newX, int newY) {
        xStart = newX;
        yStart = newY;
        if (isVisible) draw();
    }

    /**
     * Hace visible la línea.
     */
    @Override
    public void makeVisible() {
        isVisible = true;
        draw();
    }

    /**
     * Hace invisible la línea.
     */
    @Override
    public void makeInvisible() {
        if (isVisible) {
            erase();
            isVisible = false;
        }
    }

    /**
     * Dibuja la línea en el canvas.
     */
    private void draw() {
        Canvas canvas = Canvas.getCanvas();
        canvas.draw(this, color,
            new java.awt.geom.Line2D.Double(xStart, yStart, xEnd, yEnd));
        canvas.wait(10);
    }

    /**
     * Borra la línea del canvas.
     */
    private void erase() {
        Canvas canvas = Canvas.getCanvas();
        canvas.erase(this);
    }
}