import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
 * Clase de pruebas unitarias para la clase SilkRoad.
 * Verifica el funcionamiento de cada método público del ciclo 2.
 * Laura Castillo y Mariana Malagón
 * 04/10/2025
 */
public class SilkRoadTestLCMM {

    private SilkRoad road;

    /**
     * Configuración inicial antes de cada prueba.
     * Se crea una ruta con longitud 20.
     */
    @Before
    public void setUp() {
        road = new SilkRoad(20);
    }


    /**
     * Prueba constructor con longitud específica.
     * Debe crear correctamente la ruta y permitir colocar tiendas.
     */
    @Test
    public void testConstructorWithLength() {
        SilkRoad newRoad = new SilkRoad(10);
        newRoad.placeStore(5, 50);
        assertTrue("Debe permitir colocar tienda dentro del rango", newRoad.ok());
    }

    /**
     * Prueba constructor con arreglo de días (maratón).
     * Verifica que el tamaño sea suficiente para la ubicación máxima.
     */
    @Test
    public void testConstructorWithDays() {
        int[][] data = {
            {2, 3, 40}, 
            {1, 5}, 
            {2, 10, 60}
        };
        SilkRoad newRoad = new SilkRoad(data);
        newRoad.placeStore(10, 20);
        assertTrue("Debe permitir ubicación máxima (10)", newRoad.ok());
    }

    /**
     * Prueba colocar una tienda en una ubicación válida.
     */
    @Test
    public void testPlaceStore() {
        road.placeStore(5, 30);
        assertTrue("Debe poder colocarse la tienda", road.ok());
        assertEquals("Debe existir una tienda", 1, road.stores().length);
    }

    /**
     * Prueba eliminar una tienda colocada.
     */
    @Test
    public void testRemoveStore() {
        road.placeStore(5, 30);
        road.removeStore(5);
        assertTrue("Debe eliminar correctamente la tienda", road.ok());
        assertEquals(0, road.stores().length);
    }

    /**
     * Prueba colocar un robot en una ubicación válida.
     */
    @Test
    public void testPlaceRobot() {
        road.placeRobot(3);
        assertTrue("Debe poder colocarse el robot", road.ok());
        assertEquals(1, road.robots().length);
    }

    /**
     * Prueba eliminar un robot existente.
     */
    @Test
    public void testRemoveRobot() {
        road.placeRobot(3);
        road.removeRobot(3);
        assertTrue("Debe eliminar correctamente el robot", road.ok());
        assertEquals(0, road.robots().length);
    }

    /**
     * Prueba mover un robot correctamente hacia una tienda.
     */
    @Test
    public void testMoveRobotValid() {
        road.placeStore(10, 20);
        road.placeRobot(5);
        road.moveRobot(5, 5);
        assertTrue("Movimiento válido debe dejar ok=true", road.ok());
    }

    /**
     * Prueba mover un robot con ubicación inválida.
     */
    @Test
    public void testMoveRobotInvalid() {
        road.placeRobot(2);
        road.moveRobot(50, 3);
        assertFalse("Movimiento inválido debe dejar ok=false", road.ok());
    }



    /**
     * Prueba el movimiento automático de robots cuando hay tiendas.
     */
    @Test
    public void testMoveRobotsSimple() {
        road.placeRobot(0);
        road.placeStore(2, 10);
        road.moveRobots();
        assertTrue("Debe mover el robot hacia la tienda", road.ok());
    }

    /**
     * Prueba que moveRobots falle si no hay tiendas.
     */
    @Test
    public void testMoveRobotsNoStores() {
        road.placeRobot(0);
        road.moveRobots();
        assertFalse("Debe fallar si no hay tiendas", road.ok());
    }

    
    /**
     * Prueba reabastecer las tiendas vacías.
     */
    @Test
    public void testResupplyStores() {
        road.placeStore(2, 10);
        road.placeRobot(0);
        road.moveRobots();
        road.resupplyStores();
        assertTrue("Debe poder reabastecer tiendas", road.ok());
    }

    /**
     * Prueba devolver los robots a sus posiciones iniciales.
     */
    @Test
    public void testReturnRobots() {
        road.placeRobot(0);
        road.moveRobot(0, 5);
        road.returnRobots();
        assertTrue("Robots deben regresar a su posición inicial", road.ok());
    }

    /**
     * Prueba el reinicio general con reboot().
     */
    @Test
    public void testReboot() {
        road.placeStore(2, 10);
        road.placeRobot(0);
        road.moveRobots();
        road.reboot();
        assertEquals("Profit debe reiniciarse a 0", 0, road.profit());
    }

    /**
     * Prueba consultar el profit total.
     */
    @Test
    public void testProfit() {
        road.placeStore(2, 10);
        road.placeRobot(0);
        road.moveRobots();
        assertTrue("Profit debe ser mayor o igual a 0", road.profit() >= 0);
    }

    /**
     * Prueba el arreglo devuelto por stores().
     */
    @Test
    public void testStores() {
        road.placeStore(5, 15);
        int[][] s = road.stores();
        assertEquals("La tienda debe estar en ubicación 5", 5, s[0][0]);
    }

    /**
     * Prueba el arreglo devuelto por robots().
     */
    @Test
    public void testRobots() {
        road.placeRobot(3);
        int[][] r = road.robots();
        assertEquals("El robot debe estar en ubicación 3", 3, r[0][0]);
    }

    /**
     * Prueba la consulta de tiendas vaciadas.
     */
    @Test
    public void testEmptiedStores() {
        road.placeStore(2, 10);
        road.placeRobot(0);
        road.moveRobots();
        int[][] e = road.emptiedStores();
        assertTrue("Debe devolver arreglo (vacío o con valores)", e.length >= 0);
    }


    /**
     * Prueba que las ganancias por movimiento existan tras mover robots.
     */
    @Test
    public void testProfitPerMoveBasic() {
        road.placeStore(2, 10);
        road.placeRobot(0);
        road.moveRobots();
        int[][] p = road.profitPerMove();
        assertNotNull("Debe devolver un arreglo válido", p);
    }

    /**
     * Prueba que sin movimientos el arreglo esté vacío.
     */
    @Test
    public void testProfitPerMoveEmpty() {
        int[][] p = road.profitPerMove();
        assertEquals("Sin robots, la longitud debe ser 0", 0, p.length);
    }


    /**
     * Prueba que makeVisible no genere error.
     */
    @Test
    public void testMakeVisible() {
        road.makeVisible();
        assertTrue("Debe ejecutarse correctamente", true);
    }

    /**
     * Prueba que makeInvisible no genere error.
     */
    @Test
    public void testMakeInvisible() {
        road.makeInvisible();
        assertTrue("Debe ejecutarse correctamente", true);
    }

    /**
     * Prueba que finish vacíe las listas.
     */
    @Test
    public void testFinish() {
        road.placeStore(2, 10);
        road.placeRobot(0);
        road.finish();
        assertEquals("No debe haber tiendas tras finish", 0, road.stores().length);
        assertEquals("No debe haber robots tras finish", 0, road.robots().length);
    }

    /**
     * Prueba del método ok().
     */
    @Test
    public void testOk() {
        road.placeStore(2, 10);
        assertTrue("Debe indicar que la última operación fue exitosa", road.ok());
    }

    /**
     * Prueba de createExtension (entrada maratón).
     */
    @Test
    public void testCreateExtension() {
        int[][] data = {{1, 2}, {2, 3, 10}};
        road.createExtension(data);
        assertTrue("Debe crearse correctamente desde maratón", road.ok());
    }
}
