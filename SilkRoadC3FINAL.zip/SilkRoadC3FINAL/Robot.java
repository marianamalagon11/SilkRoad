import java.util.Timer;
import java.util.TimerTask;

/**
 * Clase que representa un robot en SilkRoad.
 * Cada robot tiene un identificador único, ubicación, color y contador de tiendas robadas.
 * Visualmente está compuesto por dos rectángulos cuerpo y cabeza.
 * Laura Castillo y Mariana Malagón
 * 16/09/2025
 */
public class Robot {
    private int id;
    private int x, y;
    private int initialX, initialY;
    private String color;
    private Rectangle body;
    private Rectangle head;
    private int robbedStores;
    private int totalEarnings;
    private boolean isBlinking;
    private Timer blinkTimer;

    /**
     * Constructor que crea un nuevo robot con el identificador y ubicación especificados.
     * 
     * @param id    el identificador único del robot
     * @param x     coordenada x inicial del robot en el espiral
     * @param y     coordenada y inicial del robot en el espiral
     * @param color color del robot
     */
    public Robot(int id, int x, int y, String color) {
        this.id = id;
        this.x = x;
        this.y = y;
        this.initialX = x;
        this.initialY = y;
        this.color = color;
        this.robbedStores = 0;
        this.totalEarnings = 0;
        this.isBlinking = false;

        int posX = x * 60 + 30;
        int posY = y * 60 + 30;

        body = new Rectangle();
        body.changeColor(color);
        body.changeSize(35, 35);
        body.moveTo(posX - 17, posY - 17);

        head = new Rectangle();
        head.changeColor(color);
        head.changeSize(25, 25);
        head.moveTo(posX - 12, posY - 35);
    }

    /**
     * Establece la posición inicial del robot.
     * 
     * @param x coordenada x inicial
     * @param y coordenada y inicial
     */
    public void setInitialPosition(int x, int y) {
        this.initialX = x;
        this.initialY = y;
    }

    /**
     * Devuelve el robot a su posición inicial.
     */
    public void returnToInitialPosition() {
        moveTo(initialX, initialY);
    }

    /**
     * Hace visible el robot.
     */
    public void makeVisible() {
        body.makeVisible();
        head.makeVisible();
    }

    /**
     * Hace invisible el robot.
     */
    public void makeInvisible() {
        body.makeInvisible();
        head.makeInvisible();
    }

    /**
     * Mueve el robot a una nueva ubicación en el espiral.
     * 
     * @param newX nueva coordenada x del robot en el espiral
     * @param newY nueva coordenada y del robot en el espiral
     */
    public void moveTo(int newX, int newY) {
        this.x = newX;
        this.y = newY;
        
        int posX = newX * 60 + 30;
        int posY = newY * 60 + 30;
        
        body.moveTo(posX - 17, posY - 17);
        head.moveTo(posX - 12, posY - 35);
    }

    /**
     * Realiza un robo a una tienda, tomando todo su stock disponible.
     * 
     * @param s la tienda a ser robada
     * @return la cantidad de stock robado, 0 si la tienda estaba vacía.
     */
    public int rob(Store s) {
        if (!s.isEmpty()) {
            int stolen = s.robAll();
            robbedStores++;
            return stolen;
        }
        return 0;
    }

    /**
     * Añade ganancias al total del robot.
     * 
     * @param earnings ganancias a añadir
     */
    public void addEarnings(int earnings) {
        totalEarnings += earnings;
    }

    /**
     * Hace parpadear al robot si es el de mayor ganancia.
     * 
     * @param blink true para activar parpadeo, false para desactivar
     */
    public void setBlinking(boolean blink) {
        if (blink && !isBlinking) {
            startBlinking();
        } else if (!blink && isBlinking) {
            stopBlinking();
        }
    }

    /**
     * Inicia el efecto de parpadeo del robot.
     */
    private void startBlinking() {
        isBlinking = true;
        blinkTimer = new Timer();
        blinkTimer.schedule(new TimerTask() {
            private boolean visible = true;
            public void run() {
                if (visible) {
                    makeInvisible();
                } else {
                    makeVisible();
                }
                visible = !visible;
            }
        }, 0, 500);
    }

    /**
     * Detiene el efecto de parpadeo del robot.
     */
    private void stopBlinking() {
        isBlinking = false;
        if (blinkTimer != null) {
            blinkTimer.cancel();
        }
        makeVisible();
    }

    /**
     * Obtiene el identificador único del robot.
     * 
     * @return el identificador del robot
     */
    public int getId() { 
        return id; 
    }
    
    /**
     * Obtiene la coordenada x actual del robot en el espiral.
     * 
     * @return la coordenada x
     */
    public int getX() { 
        return x; 
    }
    
    /**
     * Obtiene la coordenada y actual del robot en el espiral.
     * 
     * @return la coordenada y
     */
    public int getY() { 
        return y; 
    }
    
    /**
     * Obtiene el número total de tiendas que este robot ha robado.
     * 
     * @return el contador de tiendas robadas
     */
    public int getRobbedStores() { 
        return robbedStores; 
    }

    /**
     * Obtiene el total de ganancias acumuladas por el robot.
     * 
     * @return ganancias totales
     */
    public int getTotalEarnings() {
        return totalEarnings;
    }

    /**
     * Obtiene la coordenada x inicial del robot.
     * 
     * @return la coordenada x inicial
     */
    public int getInitialX() {
        return initialX;
    }

    /**
     * Obtiene la coordenada y inicial del robot.
     * 
     * @return la coordenada y inicial
     */
    public int getInitialY() {
        return initialY;
    }

    /**
     * Calcula la ubicación del robot basada en el tamaño del mundo.
     * 
     * @param length el tamaño del mundo.
     * @return la ubicación lineal calculada como y * length + x
     */
    public int getLocation(int length) {
        return y * length + x;
    }
}