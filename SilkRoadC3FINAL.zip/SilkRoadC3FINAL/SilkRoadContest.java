import java.util.ArrayList;
import java.util.List;

/**
 * Clase SilkRoadContest.
 * Ofrece métodos estáticos para solucionar el problema de la maratón.
 * Laura Castillo y Mariana Malagon
 * 02/10/2025
 */
public class SilkRoadContest {

    /**
     * Clase auxiliar que representa una asignación posible Robot-Tienda.
     */
    private static class OptimalMove {
        int robotIndex;
        int storeIndex;
        int netProfit;
        int metersToMove;
        int robotLocation;
        int storeLocation;

        public OptimalMove(int ri, int si, int p, int m, int rLoc, int sLoc) {
            this.robotIndex = ri;
            this.storeIndex = si;
            this.netProfit = p;
            this.metersToMove = m;
            this.robotLocation = rLoc;
            this.storeLocation = sLoc;
        }
    }

    /**
     * Resuelve el problema de la maratón (R14). Calcula la máxima utilidad diaria.
     * @param days Log de operaciones de la maratón: [[tipo, locación, valor], ...]
     * @return Array de ganancias máximas diarias.
     */
    public static int[] solve(int[][] days) {
        if (days == null || days.length == 0) {
            return new int[0];
        }

        List<int[]> currentStores = new ArrayList<>(); 
        List<int[]> currentRobots = new ArrayList<>(); 
        List<Integer> dailyProfits = new ArrayList<>();

        for (int[] operation : days) {
            int type = operation[0];
            int location = operation.length >= 2 ? operation[1] : -1;
            int tenges = operation.length >= 3 ? operation[2] : 0;

            if (type == 1) { 
                currentRobots.add(new int[]{location});
            } else if (type == 2) { 
                currentStores.add(new int[]{location, tenges});
            }

            int maxDailyProfit = calculateMaxProfit(currentStores, currentRobots);
            dailyProfits.add(maxDailyProfit);
        }

        int[] result = new int[dailyProfits.size()];
        for (int i = 0; i < dailyProfits.size(); i++) {
            result[i] = dailyProfits.get(i);
        }
        return result;
    }

    /**
     * Calcula la ganancia máxima probando todas las combinaciones posibles.
     */
    private static int calculateMaxProfit(List<int[]> stores, List<int[]> robots) {
        if (stores.isEmpty() || robots.isEmpty()) {
            return 0;
        }

        int numStores = stores.size();
        int[] bestProfit = {0};
        
        boolean[] used = new boolean[numStores];
        int[] robotPositions = new int[robots.size()];
        for (int i = 0; i < robots.size(); i++) {
            robotPositions[i] = robots.get(i)[0];
        }
        
        tryAllAssignments(stores, robots, robotPositions, used, 0, bestProfit);
        
        return bestProfit[0];
    }

    /**
     * Prueba recursivamente todas las asignaciones posibles.
     */
    private static void tryAllAssignments(List<int[]> stores, List<int[]> robots, int[] robotPos, boolean[] used, int currentProfit, int[] bestProfit) {

        if (currentProfit > bestProfit[0]) {
            bestProfit[0] = currentProfit;
        }
        
        for (int s = 0; s < stores.size(); s++) {
            if (!used[s]) {
                int storePos = stores.get(s)[0];
                int storeStock = stores.get(s)[1];
                
                for (int r = 0; r < robots.size(); r++) {
                    int distance = Math.abs(storePos - robotPos[r]);
                    int profit = storeStock - distance;
                    int oldPos = robotPos[r];
                    used[s] = true;
                    robotPos[r] = storePos;
                    tryAllAssignments(stores, robots, robotPos, used, currentProfit + profit, bestProfit);
                    used[s] = false;
                    robotPos[r] = oldPos;
                }
            }
        }
    }

    /**
     * Simula la solución óptima día a día (R15).
     * @param days Log de operaciones de la maratón.
     * @param slow Indica si la simulación debe tener una pausa visual entre movimientos.
     */
    public static void simulate(int[][] days, boolean slow) {
        if (days == null || days.length == 0) return;
        
        SilkRoad simulator = new SilkRoad(days); 
        
        if (slow) {
            simulator.makeVisible();
        }

        List<int[]> currentStores = new ArrayList<>(); 
        List<int[]> currentRobots = new ArrayList<>(); 
        
        final int SIMULATION_PAUSE_TIME = 500; 

        for (int[] operation : days) {
            
            simulator.finish(); 
            
            int type = operation[0];
            int location = operation.length >= 2 ? operation[1] : -1;
            int tenges = operation.length >= 3 ? operation[2] : 0;
            
            if (type == 1) { 
                currentRobots.add(new int[]{location});
            } else if (type == 2) { 
                currentStores.add(new int[]{location, tenges});
            }
            
            for (int[] store : currentStores) {
                simulator.placeStore(store[0], store[1]); 
            }
            for (int[] robot : currentRobots) {
                simulator.placeRobot(robot[0]);
            }

            List<OptimalMove> optimalMoves = getOptimalMovesForSimulation(currentStores, currentRobots);
            
            for (OptimalMove move : optimalMoves) {
                simulator.moveRobot(move.robotLocation, move.metersToMove); 
                
                if (slow) {
                    Canvas.getCanvas().wait(SIMULATION_PAUSE_TIME);
                }
            }

            simulator.reboot(); 
        }
    }
    
    /**
     * Obtiene los movimientos para la simulación usando greedy.
     */
    private static List<OptimalMove> getOptimalMovesForSimulation(List<int[]> stores, List<int[]> robots) {
        List<OptimalMove> moves = new ArrayList<>();
        
        if (stores.isEmpty() || robots.isEmpty()) {
            return moves;
        }

        int numStores = stores.size();
        int numRobots = robots.size();
        
        boolean[] visitedStores = new boolean[numStores];
        int[] robotPos = new int[numRobots];
        
        for (int i = 0; i < numRobots; i++) {
            robotPos[i] = robots.get(i)[0];
        }
        
        while (true) {
            int bestRobot = -1;
            int bestStore = -1;
            int bestProfit = 0;
            
            for (int r = 0; r < numRobots; r++) {
                for (int s = 0; s < numStores; s++) {
                    if (!visitedStores[s]) {
                        int storePos = stores.get(s)[0];
                        int storeStock = stores.get(s)[1];
                        int distance = Math.abs(storePos - robotPos[r]);
                        int profit = storeStock - distance;
                        
                        if (profit > bestProfit) {
                            bestProfit = profit;
                            bestRobot = r;
                            bestStore = s;
                        }
                    }
                }
            }
            
            if (bestRobot == -1) break;
            
            int robotInitialPos = robotPos[bestRobot];
            int storePos = stores.get(bestStore)[0];
            int metersToMove = storePos - robotInitialPos;
            
            moves.add(new OptimalMove(
                bestRobot,
                bestStore,
                bestProfit,
                metersToMove,
                robotInitialPos,
                storePos
            ));
            
            visitedStores[bestStore] = true;
            robotPos[bestRobot] = storePos;
        }
        
        return moves;
    }
}
