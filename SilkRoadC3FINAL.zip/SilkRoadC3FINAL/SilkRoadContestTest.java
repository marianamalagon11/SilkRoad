import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.*;

/**
 * Pruebas unitarias para la clase SilkRoadContest.
 * Autor: Laura Castillo y Mariana Malagón
 * Fecha: 05/10/2025
 */
public class SilkRoadContestTest {

    /**
     * Caso base: arreglo vacío → debe devolver arreglo vacío.
     */
    @Test
    public void testEmptyDays() {
        int[][] days = new int[0][];
        int[] result = SilkRoadContest.solve(days);
        assertEquals(0, result.length, "El resultado debe ser un arreglo vacío");
    }

    /**
     * Caso con solo robots (sin tiendas) → siempre ganancia 0.
     */
    @Test
    public void testOnlyRobots() {
        int[][] days = {
            {1, 3},
            {1, 5}
        };
        int[] expected = {0, 0};
        assertArrayEquals(expected, SilkRoadContest.solve(days),
                "Si solo hay robots, la ganancia debe ser 0 en todos los días");
    }

    /**
     * Caso con solo tiendas (sin robots) → ganancia 0.
     */
    @Test
    public void testOnlyStores() {
        int[][] days = {
            {2, 5, 10},
            {2, 8, 15}
        };
        int[] expected = {0, 0};
        assertArrayEquals(expected, SilkRoadContest.solve(days),
                "Si solo hay tiendas, la ganancia debe ser 0 en todos los días");
    }

    /**
     * Caso simple: 1 robot y 1 tienda.
     */
    @Test
    public void testOneRobotOneStore() {
        int[][] days = {
            {1, 3},
            {2, 6, 10}
        };
        
        int[] expected = {0, 7};
        assertArrayEquals(expected, SilkRoadContest.solve(days),
                "Debe calcular correctamente la utilidad diaria con un robot y una tienda");
    }

    /**
     * Caso con múltiples robots y tiendas.
     * CORRECCIÓN: el día 3 la mejor opción es mover el robot en 7 a la tienda en 5:
     * 10 - |5-7| = 8, por eso el valor esperado es 8 (no 5).
     */
    @Test
    public void testMultipleRobotsStores() {
        int[][] days = {
            {1, 0},     
            {2, 5, 10}, 
            {1, 7},
            {2, 9, 6} 
        };
        
        int[] expected = {0, 5, 8, 10};
        assertArrayEquals(expected, SilkRoadContest.solve(days),
                "Debe calcular correctamente la máxima utilidad total cada día");
    }

    /**
     * Caso donde moverse genera pérdida inicial pero mejora el total.
     */
    @Test
    public void testNegativeIntermediateProfit() {
        int[][] days = {
            {1, 0},    
            {2, 2, 1},  
            {2, 5, 10} 
        };
        
        int[] result = SilkRoadContest.solve(days);
        assertEquals(6, result[2], "Debe considerar casos donde moverse con pérdida mejora el total");
    }

    /**
     * Verifica que el método de simulación no lance errores.
     */
    @Test
    public void testSimulationNoCrash() {
        int[][] days = {
            {1, 2},
            {2, 4, 10}
        };

        assertDoesNotThrow(() -> {
            SilkRoadContest.simulate(days, false);
        }, "El método simulate no debe lanzar excepciones");
    }
}
