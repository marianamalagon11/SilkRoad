/**
 * Clase que representa una tienda en el mundo SilkRoad.
 * Cada tienda tiene una ubicación, color, stock actual y stock máximo.
 * Visualmente está compuesta por un rectángulo (base) y un triángulo (techo).
 * Laura Castillo y Mariana Malagón
 * 06/09/2025
 */
public class Store {
    private int x, y;
    private String color;
    private int stock;
    private int maxStock;
    private Rectangle base;
    private Triangle roof;

    /**
     * Constructor que crea una nueva tienda en la ubicación especificada.
     * @param x      coordenada x de la tienda
     * @param y      coordenada y de la tienda
     * @param color  color de la tienda
     * @param stock  cantidad inicial de stock, también establece el stock máximo
     */
    public Store(int x, int y, String color, int stock) {
        this.x = x;
        this.y = y;
        this.color = color;
        this.stock = stock;
        this.maxStock = stock;

        base = new Rectangle();
        base.changeColor(color);
        base.changeSize(40, 40);
        base.moveTo(x * 60, y * 60+20);

        roof = new Triangle();
        roof.changeColor(color);
        roof.changeSize(20, 40);
        roof.moveTo(x * 60 + 20, y * 60 - 2);
    }

    /**
     * Reabastece la tienda con su stock máximo.
     */
    public void resupply() {
        stock = maxStock;
    }

    /**
     * Roba todo el stock disponible de la tienda.
     * @return la cantidad de stock robado
     */
    public int robAll() {
        int stolen = stock;
        stock = 0;
        return stolen;
    }

    /**
     * Hace visible la tienda.
     */
    public void makeVisible() {
        base.makeVisible();
        roof.makeVisible();
    }

    /**
     * Hace invisible la tienda.
     */
    public void makeInvisible() {
        base.makeInvisible();
        roof.makeInvisible();
    }

    /**
     * Obtiene la coordenada x de la tienda.
     * @return la coordenada x
     */
    public int getX() { 
        return x; 
    }
    
    /**
     * Obtiene la coordenada y de la tienda.
     * @return la coordenada y
     */
    public int getY() { 
        return y; 
    }
    
    /**
     * Obtiene el stock actual de la tienda.
     * @return el stock actual
     */
    public int getStock() { 
        return stock; 
    }
    
    /**
     * Obtiene el stock máximo de la tienda.
     * @return el stock máximo
     */
    public int getMaxStock() { 
        return maxStock; 
    }
    
    /**
     * Verifica si la tienda sin stock.
     * @return true si la tienda está vacía, false en caso contrario
     */
    public boolean isEmpty() { 
        return stock <= 0; 
    }

    /**
     * Calcula la ubicación de la tienda basada en el tamaño del "mundo".
     * @param length el tamaño del mundo (ancho/alto)
     * @return la ubicación lineal calculada como y * length + x
     */
    public int getLocation(int length) {
        return y * length + x;
    }
}