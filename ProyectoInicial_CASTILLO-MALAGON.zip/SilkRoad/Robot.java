/**
 * Clase que representa un robot en SilkRoad.
 * Cada robot tiene un identificador único, ubicación, color y contador de tiendas robadas.
 * Visualmente está compuesto por dos rectángulos cuerpo y cabeza.
 * Laura Castillo y Mariana Malagón
 * 06/09/2025
 */
public class Robot {
    private int id;
    private int x, y;
    private String color;
    private Rectangle body;
    private Rectangle head;
    private int robbedStores;

    /**
     * Constructor que crea un nuevo robot con el identificador y ubicación especificados.
     * @param id    el identificador único del robot
     * @param x     coordenada x inicial del robot
     * @param y     coordenada y inicial del robot
     * @param color color del robot
     */
    public Robot(int id, int x, int y, String color) {
        this.id = id;
        this.x = x;
        this.y = y;
        this.color = color;
        this.robbedStores = 0;

        body = new Rectangle();
        body.changeColor(color);
        body.changeSize(40, 40);
        body.moveTo(x * 60, y * 60 + 20);

        head = new Rectangle();
        head.changeColor(color);
        head.changeSize(20, 20);
        head.moveTo(x * 60 + 10, y * 60);
    }

    /**
     * Hace visible el robot.
     */
    public void makeVisible() {
        body.makeVisible();
        head.makeVisible();
    }

    /**
     * Hace invisible el robot.
     */
    public void makeInvisible() {
        body.makeInvisible();
        head.makeInvisible();
    }

    /**
     * Mueve el robot a una nueva ubicación.
     * @param newX nueva coordenada x del robot
     * @param newY nueva coordenada y del robot
     */
    public void moveTo(int newX, int newY) {
        this.x = newX;
        this.y = newY;
        body.moveTo(x * 60, y * 60 + 20);
        head.moveTo(x * 60 + 10, y * 60);
    }

    /**
     * Realiza un robo a una tienda, tomando todo su stock disponible.
     * @param s la tienda a ser robada
     * @return la cantidad de stock robado,0 si la tienda estaba vacía.
     */
    public int rob(Store s) {
        if (!s.isEmpty()) {
            int stolen = s.robAll();
            robbedStores++;
            return stolen;
        }
        return 0;
    }

    /**
     * Obtiene el identificador único del robot.
     * @return el identificador del robot
     */
    public int getId() { 
        return id; 
    }
    
    /**
     * Obtiene la coordenada x actual del robot.
     * @return la coordenada x
     */
    public int getX() { 
        return x; 
    }
    
    /**
     * Obtiene la coordenada y actual del robot.
     * @return la coordenada y
     */
    public int getY() { 
        return y; 
    }
    
    /**
     * Obtiene el número total de tiendas que este robot ha robado.
     * @return el contador de tiendas robadas
     */
    public int getRobbedStores() { 
        return robbedStores; 
    }

    /**
     * Calcula la ubicación del robot basada en el tamaño del mundo.
     * @param length el tamaño del mundo.
     * @return la ubicación lineal calculada como y * length + x
     */
    public int getLocation(int length) {
        return y * length + x;
    }
}