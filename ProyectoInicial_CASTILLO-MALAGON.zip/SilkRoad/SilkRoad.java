import java.util.*;

/**
 * Clase que representa SilkRoad, gestionan las tiendas, los robots y sus interacciones.
 * Permite colocar o remover tiendas y robots, mover robots para robar tiendas, y guardar y ver las ganancias.
 * Laura Castillo y Mariana Malagón
 * 06/09/2025
 */
public class SilkRoad {
    private int length;
    private ArrayList<Store> stores;
    private ArrayList<Robot> robots;
    private int profit;
    private ProgressBar bar;
    private boolean lastOk;

    /**
     * Constructor que crea una nueva instancia de SilkRoad.
     * 
     * @param length La longitud de la ruta
     */
    public SilkRoad(int length) {
        this.length = length;
        this.stores = new ArrayList<>();
        this.robots = new ArrayList<>();
        this.profit = 0;
        this.lastOk = true;
        bar = new ProgressBar(300, 20);
    }

    /**
     * Coloca una tienda en la ubicación especificada con un stock de tenges inicial.
     * 
     * @param location Ubicación en coordenadas lineales (0 a length*length-1)
     * @param tenges  Cantidad inicial de stock de la tienda
     */
    public void placeStore(int location, int tenges) { 
        int x = location % length; 
        int y = location / length; 
        String[] colors = {"green", "magenta", "white"}; 
        String c = colors[stores.size() % colors.length]; 
        Store s = new Store(x, y, c, tenges); 
        stores.add(s); s.makeVisible(); 
        lastOk = true; 
    }

    /**
     * Remueve una tienda de la ubicación especificada.
     * 
     * @param location Ubicación de la tienda a remover
     * @return true si se encontró y removió la tienda, false en caso contrario
     */
    public void removeStore(int location) {
        Store toRemove = null;
        for (Store s : stores) {
            if (s.getLocation(length) == location) {
                toRemove = s;
                break;
            }
        }
        if (toRemove != null) {
            toRemove.makeInvisible();
            stores.remove(toRemove);
            lastOk = true;
        } else {
            lastOk = false;
        }
    }

    /**
     * Coloca un robot en la ubicación especificada.
     * 
     * @param location Ubicación donde colocar el robot
     */
    public void placeRobot(int location) { 
        int x = location % length; 
        int y = location / length; 
        String[] colors = {"red", "black", "blue", "yellow"}; 
        String c = colors[robots.size() % colors.length]; 
        Robot r = new Robot(robots.size() + 1, x, y, c); 
        robots.add(r); 
        r.makeVisible(); 
        lastOk = true; 
    }

    /**
     * Remueve un robot de la ubicación especificada.
     * 
     * @param location Ubicación del robot a remover
     * @return true si se encontró y removió el robot, false en caso contrario
     */
    public void removeRobot(int location) {
        Robot toRemove = null;
        for (Robot r : robots) {
            if (r.getLocation(length) == location) {
                toRemove = r;
                break;
            }
        }
        if (toRemove != null) {
            toRemove.makeInvisible();
            robots.remove(toRemove);
            lastOk = true;
        } else {
            lastOk = false;
        }
    }

    /**
     * Mueve un robot desde su ubicación actual una cantidad de metros.
     * Si el robot cae en una tienda, la roba y suma las ganancias que la tienda tenía.
     * 
     * @param location Ubicación actual del robot a mover
     * @param meters  Cantidad de metros a mover.
     */
    public void moveRobot(int location, int meters) {
        for (Robot r : robots) {
            if (r.getLocation(length) == location) {
                int newLocation = (location + meters) % (length * length);
                int nx = newLocation % length;
                int ny = newLocation / length;
                r.moveTo(nx, ny);

                for (Store s : stores) {
                    if (s.getX() == nx && s.getY() == ny) {
                        int stolen = r.rob(s);
                        profit += stolen;
                        bar.update(profit, getMaxProfit());
                    }
                }
                lastOk = true;
                return;
            }
        }
        lastOk = false;
    }

    /**
     * Reabastece todas las tiendas con su stock máximo.
     */
    public void resupplyStores() {
        for (Store s : stores) {
            s.resupply();
        }
        lastOk = true;
    }

    /**
     * Devuelve todos los robots a sus posiciones iniciales.
     */
    public void returnRobots() {
        int i = 0;
        for (Robot r : robots) {
            int x = i % length;
            int y = i / length;
            r.moveTo(x, y);
            i++;
        }
        lastOk = true;
    }

    /**
     * Reinicia el estado del juego: profit a 0, reabastece tiendas y devuelve robots.
     */
    public void reboot() {
        profit = 0;
        for (Store s : stores) s.resupply();
        returnRobots();
        bar.update(0, getMaxProfit());
        lastOk = true;
    }

    /**
     * Retorna el profit total acumulado por los robos.
     * @return El profit total acumulado
     */
    public int porfit() {
        return profit;
    }

    /**
     * Retorna un array con información de todas las tiendas.
     * 
     * @return Array ordenado por ubicación donde cada fila contiene: [ubicación, stock_actual]
     */
    public int[][] stores() {
        int[][] arr = new int[stores.size()][2];
        for (int i = 0; i < stores.size(); i++) {
            arr[i][0] = stores.get(i).getLocation(length);
            arr[i][1] = stores.get(i).getStock();
        }
        Arrays.sort(arr, (a, b) -> a[0] - b[0]);
        return arr;
    }

    /**
     * Retorna un array con información de todos los robots.
     * 
     * @return Array ordenado por ubicación donde cada fila contiene: [ubicación, cantidad_de_tiendas_robadas]
     */
    public int[][] robots() {
        int[][] arr = new int[robots.size()][2];
        for (int i = 0; i < robots.size(); i++) {
            arr[i][0] = robots.get(i).getLocation(length);
            arr[i][1] = robots.get(i).getRobbedStores();
        }
        Arrays.sort(arr, (a, b) -> a[0] - b[0]);
        return arr;
    }

    /**
     * Hace visibles todos los elementos: tiendas, robots y barra de progreso.
     */
    public void makeVisible() {
        for (Store s : stores) s.makeVisible();
        for (Robot r : robots) r.makeVisible();
        bar.makeVisible();
    }

    /**
     * Hace invisibles todos los elementos.
     */
    public void makeInvisible() {
        for (Store s : stores) s.makeInvisible();
        for (Robot r : robots) r.makeInvisible();
        bar.makeInvisible();
    }

    /**
     * Finaliza la simulación: hace invisibles todos los elementos y limpia las listas.
     */
    public void finish() {
        makeInvisible();
        stores.clear();
        robots.clear();
        profit = 0;
    }

    /**
     * Indica si la última operación fue exitosa.
     * @return true si la última operación fue exitosa, false en caso contrario
     */
    public boolean ok() {
        return lastOk;
    }

    /**
     * Calcula el profit máximo posible, que es la suma del stock máximo de todas las tiendas.
     * @return El profit máximo
     */
    private int getMaxProfit() {
        int total = 0;
        for (Store s : stores) total += s.getMaxStock();
        return total;
    }
}